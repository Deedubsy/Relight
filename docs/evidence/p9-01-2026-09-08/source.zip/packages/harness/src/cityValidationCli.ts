/** Fresh campaign survey. This CLI writes new evidence only; P9-04 adds resumable population execution. */
import { readdirSync, readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { resolve, relative, join } from 'node:path';
import { createHash } from 'node:crypto';
import { citySeeds, cityValidationRun } from './cityValidationRun';
import { stamp } from './provenance';

const args=process.argv.slice(2),options=new Map<string,string>();
for(let i=0;i<args.length;i+=2){if(!['--seeds','--out'].includes(args[i])||!args[i+1]||options.has(args[i]))throw Error('usage: city:validate --seeds 3,4,5,8,11,13 --out NEW_DIRECTORY');options.set(args[i],args[i+1]);}
if(!options.get('--out'))throw Error('--out is required; existing evidence is never overwritten');
const seeds=citySeeds(options.get('--seeds')??'3,4,5,8,11,13'),out=resolve(options.get('--out')!);
if(existsSync(out))throw Error('output directory exists; choose a new evidence directory');
const root=process.cwd(),files:string[]=[];
function collect(dir:string){for(const entry of readdirSync(dir,{withFileTypes:true})){const p=join(dir,entry.name);if(entry.isDirectory())collect(p);else if(/\.(ts|json)$/.test(entry.name))files.push(p);}}
for(const dir of ['packages/sim/src','packages/harness/src'])collect(resolve(dir));
for(const p of ['package.json','package-lock.json','packages/sim/package.json','packages/harness/package.json'])files.push(resolve(p));files.sort();
const hashes=()=>Object.fromEntries(files.map(p=>[relative(root,p).replaceAll('\\','/'),createHash('sha256').update(readFileSync(p)).digest('hex')]));
const sourceFiles=hashes(),sourceDigest=createHash('sha256').update(JSON.stringify(sourceFiles)).digest('hex'),provenance=stamp({kind:'campaign',ruleset:'exploration-v2',opening:'culdesac-v1'});
mkdirSync(out,{recursive:true});
const write=(name:string,data:unknown)=>writeFileSync(join(out,name),JSON.stringify(data,null,2)+'\n',{flag:'wx'});
write('manifest.json',{...provenance,sourceDigest,sourceFiles,seeds,method:'Fresh current campaign per declared seed; private-copy physical queries; repeated query and saved-state report comparison. Query timings include generation/clone/load and warm caches. No ordinary paid gameplay or human fairness claim. Partial runs retain their seed files; this runner does not resume.',human_play:'not_run'});
const rows=[];
for(const seed of seeds){const row=cityValidationRun(seed);write(`seed-${seed}.json`,{...provenance,sourceDigest,...row});rows.push({seed,status:row.status,failures:row.report?.failures??[row.failure],wallMs:row.wallMs});console.log(`${seed}: ${row.status}; ${row.report?.failures.length??1} findings`);}
const sourceUnchanged=JSON.stringify(hashes())===JSON.stringify(sourceFiles),failed=rows.filter(r=>r.status==='failed').length;
write('summary.json',{...provenance,sourceDigest,sourceUnchanged,attempted:seeds.length,passed:seeds.length-failed,failed,rows});
if(failed||!sourceUnchanged)process.exitCode=1;
