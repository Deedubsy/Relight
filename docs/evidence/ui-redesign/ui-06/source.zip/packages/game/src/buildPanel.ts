import {buildStock,lockReason,KIND_LABEL,knownEquipment,ROUNDS_PER_MAG,type Kind} from '@relight/sim';
import {buildCatalogue,buildCategory,visibleBuildCatalogue,type BuildCategory} from './buildCatalogue';
import {quickbarView,readUiPreferences,saveQuickbar,assignQuickbar,DEFAULT_QUICKBAR,QUICKBAR_KEYS,type QuickTool} from './uiPreferences';
import {el,type UiShell} from './uiShell';
import {shortcut} from './controls';
import type {Session} from './session';
const purposes:Record<BuildCategory,string>={Production:'Turn local resources into factory supplies.',Logistics:'Move items between real machines and stores.',Power:'Supply and light your local circuits.',Defence:'Protect the factory and its approaches.'};
const short:Partial<Record<QuickTool,string>>={excavator:'Excav.',assembler:'Assem.',generator:'Gen.',floodlight:'Flood',underground:'Undergr.',tramstop:'Stop',barricade:'Barric.',substation:'Subst.',bigpole:'Big pole',arclamp:'Arc lamp'};
const price=(cost:Record<string,number>)=>Object.entries(cost).filter(([,n])=>n>0).map(([k,n])=>`${n} ${k}`).join(' + ')||'No material cost';
/** UI-03: catalogue and shortcuts are views over current pocket costs and discovered plans. */
export function createBuildPanel(session:Session,root:HTMLElement,shell:UiShell,pick:(tool:QuickTool)=>void,selected:()=>string,rotate:()=>void,cancel:()=>void,history:HTMLElement,clipboard:HTMLElement|null,library:HTMLElement|null){
  quickbarView.slots=readUiPreferences().quickbar;
  root.replaceChildren();root.classList.add('build-catalogue');
  const tabs=el('div','build-tabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Build sections');
  const bodies=new Map<string,HTMLElement>(),tabButtons=new Map<string,HTMLButtonElement>();let active='Equipment';
  function show(name:string){active=name;for(const [id,body] of bodies){body.hidden=id!==name;tabButtons.get(id)!.setAttribute('aria-selected',String(id===name));}}
  for(const name of ['Equipment','Infrastructure','Library','Shortcuts']){const b=el('button',undefined,name),body=el('div','build-tab-body');b.id=`build-tab-${name}`;b.setAttribute('role','tab');b.setAttribute('aria-controls',`build-body-${name}`);body.id=`build-body-${name}`;body.setAttribute('role','tabpanel');body.setAttribute('aria-labelledby',b.id);b.onclick=()=>show(name);tabs.append(b);bodies.set(name,body);tabButtons.set(name,b);}
  root.append(tabs,...bodies.values());
  const equipment=bodies.get('Equipment')!,search=el('input');search.type='search';search.placeholder='Find equipment';search.setAttribute('aria-label','Find equipment');equipment.append(search);
  const groups=new Map<BuildCategory,{root:HTMLElement;cards:HTMLElement[]}>(),cards:{kind:Exclude<Kind,'depot'>;root:HTMLElement;button:HTMLButtonElement;stock:HTMLElement;reason:HTMLElement}[]=[];
  for(const category of ['Production','Logistics','Power','Defence'] as const){const section=el('section','build-group');section.append(el('h2',undefined,category),el('p','hint',purposes[category]));groups.set(category,{root:section,cards:[]});equipment.append(section);}
  for(const entry of buildCatalogue(true)){
    const article=el('article','build-card'),b=el('button','build-select',entry.label),stock=el('div','build-stock'),reason=el('p','build-reason'),assign=el('button',undefined,'Assign shortcut');
    b.setAttribute('aria-label',`Build ${entry.label}`);b.onclick=()=>pick(entry.kind);assign.setAttribute('aria-label',`Assign ${entry.label} shortcut`);assign.onclick=()=>{show('Shortcuts');assignmentTool.value=entry.kind;assignmentTool.focus();};
    article.append(b,el('p','hint',entry.what),el('div','build-price',`Material price: ${price(buildStock(entry.kind,{}).cost)}`),stock,reason,assign);const g=groups.get(buildCategory(entry.kind))!;g.root.append(article);g.cards.push(article);cards.push({kind:entry.kind,root:article,button:b,stock,reason});
  }
  const rifle=el('button',undefined,'Equip rifle');rifle.onclick=()=>pick('rifle');equipment.append(el('h2',undefined,'Equipment'),rifle);
  const infrastructure=bodies.get('Infrastructure')!;infrastructure.append(el('h2',undefined,'Infrastructure tools'),el('p','hint','Copy, plan and pack real factory layouts. Orders spend stock only when built.'),history);if(clipboard)infrastructure.append(clipboard);
  if(library)bodies.get('Library')!.append(library);
  const plansHint=el('p','hint','Explore to discover construction plans.'),libraryHint=el('p','hint','Explore to discover construction plans.');infrastructure.append(plansHint);bodies.get('Library')!.append(libraryHint);
  const shortcuts=bodies.get('Shortcuts')!,assignmentTool=el('select'),assignmentSlot=el('select'),apply=el('button',undefined,'Assign to slot'),clear=el('button',undefined,'Clear slot'),left=el('button',undefined,'Move slot left'),right=el('button',undefined,'Move slot right'),reset=el('button',undefined,'Restore default slots'),notice=el('p','hint');
  assignmentTool.id='quickbar-tool';assignmentSlot.id='quickbar-slot';const toolLabel=el('label',undefined,'Equipment to assign'),slotLabel=el('label',undefined,'Shortcut slot');toolLabel.htmlFor=assignmentTool.id;slotLabel.htmlFor=assignmentSlot.id;
  for(let i=0;i<10;i++){const option=el('option',undefined,`Slot ${QUICKBAR_KEYS[i]}`);option.value=String(i);assignmentSlot.append(option);}
  shortcuts.append(el('h2',undefined,'Your ten shortcuts'),el('p','hint','Slots stay in order. Assigning an item already on the bar swaps the two slots. Carried counts are real pocket stock; changing shortcuts never moves items.'),toolLabel,assignmentTool,slotLabel,assignmentSlot,apply,clear,left,right,reset,notice);
  const save=()=>{notice.textContent=saveQuickbar(quickbarView.slots)?'Shortcuts saved for this browser.':'Shortcuts changed for this session; browser storage is unavailable.';};
  apply.onclick=()=>{quickbarView.slots=assignQuickbar(quickbarView.slots,Number(assignmentSlot.value),assignmentTool.value as QuickTool);save();};
  clear.onclick=()=>{quickbarView.slots=assignQuickbar(quickbarView.slots,Number(assignmentSlot.value),null);save();};
  const move=(delta:number)=>{const i=Number(assignmentSlot.value),j=i+delta;if(j<0||j>9)return;const a=quickbarView.slots;[a[i],a[j]]=[a[j],a[i]];assignmentSlot.value=String(j);save();};left.onclick=()=>move(-1);right.onclick=()=>move(1);reset.onclick=()=>{quickbarView.slots=[...DEFAULT_QUICKBAR];save();};
  const bar=el('div','quickbar');bar.setAttribute('role','group');bar.setAttribute('aria-label','Quickbar');const slots=QUICKBAR_KEYS.map((key,i)=>{const b=el('button','quickbar-slot'),number=el('kbd',undefined,key),name=el('span','quickbar-name'),count=el('span','quickbar-count');b.append(number,name,count);b.onclick=()=>{const tool=quickbarView.slots[i];if(tool&&(tool==='rifle'||knownEquipment(session.state,tool)))pick(tool);};bar.append(b);return {b,name,count};});
  const toolbar=el('div','placement-toolbar'),selection=el('span'),rotateButton=el('button',undefined,`Rotate (${shortcut('rotate')})`),cancelButton=el('button',undefined,'Cancel (Esc)'),edit=el('button',undefined,'Edit shortcuts');rotateButton.onclick=rotate;cancelButton.onclick=cancel;edit.onclick=()=>{shell.open('build');show('Shortcuts');};toolbar.append(selection,rotateButton,cancelButton,edit);
  const nav=document.querySelector('.ui-navigation')!,more=el('details','quickbar-more'),moreTitle=el('summary',undefined,'More'),moreActions=el('div','quickbar-more-actions');more.append(moreTitle,moreActions);nav.append(more);moreActions.addEventListener('click',()=>{more.open=false;});nav.prepend(bar,toolbar);shell.protect(bar);shell.protect(toolbar);show('Equipment');let optionsKey='';
  return {update(){
    for(const child of Array.from(nav.children))if(child instanceof HTMLButtonElement&&['Management','Construction','Help','Navigation'].includes(child.textContent??''))moreActions.append(child);
    const compact=document.body.classList.contains('ui-short');if(compact&&edit.parentElement!==moreActions)moreActions.append(edit);else if(!compact&&edit.parentElement!==toolbar)toolbar.append(edit);
    rotateButton.textContent=`Rotate (${shortcut('rotate')})`;toolbar.hidden=compact&&selected()==='hand';
    const st=session.state,tool=selected(),visible=visibleBuildCatalogue(st),known=new Set(visible.map(b=>b.kind)),filter=search.value.trim().toLowerCase();
    const plansKnown=!!st.campaign?.clipboard||!!st.campaign?.recruits?.sites.some(s=>s.kind==='foreman'&&(s.seenAt>=0||s.recruitedAt>=0));if(clipboard)clipboard.hidden=!plansKnown;if(library)library.hidden=!plansKnown;plansHint.hidden=libraryHint.hidden=plansKnown;
    const optionKey=visible.map(b=>b.kind).join('|');if(optionsKey!==optionKey){optionsKey=optionKey;const previous=assignmentTool.value;assignmentTool.replaceChildren(...[...visible.map(b=>({value:b.kind,label:b.label})),{value:'rifle',label:'Rifle'}].map(b=>{const o=el('option',undefined,b.label);o.value=b.value;return o;}));if(Array.from(assignmentTool.options).some(o=>o.value===previous))assignmentTool.value=previous;}
    for(const card of cards){const visible=known.has(card.kind)&&(!filter||`${KIND_LABEL[card.kind]} ${buildCategory(card.kind)}`.toLowerCase().includes(filter));card.root.hidden=!visible;if(!visible)continue;const stock=buildStock(card.kind,st.engineer.inv),locked=lockReason(st,card.kind);card.button.disabled=!!locked;card.button.setAttribute('aria-pressed',String(tool===card.kind));card.stock.textContent=`${stock.carried} carried${stock.carried?' · packed machine used first':stock.affordability.ok?' · build from materials':''}`;card.reason.textContent=locked?`Locked: ${locked}`:stock.carried?'Materials are kept when placing a carried machine.':stock.shortage.length?`Pockets need ${stock.shortage.map(s=>`${s.count} ${s.item}`).join(' + ')}`:'Materials available in pockets.';}
    for(const group of groups.values())group.root.hidden=group.cards.every(c=>c.hidden);
    rifle.hidden=!!filter&&!('rifle'.includes(filter));
    for(let i=0;i<10;i++){const slot=slots[i],item=quickbarView.slots[i],visible=!!item&&(item==='rifle'||known.has(item)),label=visible?(item==='rifle'?'Rifle':KIND_LABEL[item!]):item?'Undiscovered':'Empty',locked=visible&&item!=='rifle'?lockReason(st,item!):'';slot.b.disabled=!visible||!!locked;slot.b.setAttribute('aria-label',`Slot ${QUICKBAR_KEYS[i]}: ${label}${locked?` — locked: ${locked}`:''}`);slot.b.setAttribute('aria-pressed',String(visible&&item===tool));slot.b.title=label+(locked?` · ${locked}`:'');slot.name.textContent=visible?(short[item!]??label):item?'—':'Empty';slot.count.textContent=visible?(item==='rifle'?`${Math.floor((st.engineer.inv.magazine??0)*ROUNDS_PER_MAG)} rds`:`${Math.floor(st.engineer.inv[item!]??0)} carried`):'Reserved';}
    selection.textContent=tool==='hand'?'Empty hand':tool==='rifle'?'Rifle equipped':`${KIND_LABEL[tool as Kind]} selected`;
    rotateButton.hidden=tool==='hand'||tool==='rifle';cancelButton.hidden=tool==='hand';bar.inert=toolbar.inert=shell.paused();
    left.disabled=assignmentSlot.value==='0';right.disabled=assignmentSlot.value==='9';
    // Keep the current tab through drawer closure and repeated placement.
    root.dataset.activeTab=active;
  }};
}
