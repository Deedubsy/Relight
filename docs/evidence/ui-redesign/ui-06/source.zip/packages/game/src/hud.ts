import {preferenceView,saveUiPreferences} from './uiPreferences';
import {blockName,blockOfTile,campaignClock,campaignAlerts,currentGoal,invStacks,INV_STACKS,ENGINEER_HP,ROUNDS_PER_MAG,KIND_LABEL,navigationTargets,ground,T_RIVER,T_STREET,campaignDiscoveries,type NextAction} from '@relight/sim';
import {el,uiInput} from './uiShell';
import {shortcut} from './controls';
import {hudInset,objectiveView,type View} from './view';
import type {Session} from './session';
import type {Panel} from './panel';
import type {WorldScene} from './worldScene';
/** One passive read model over the existing simulation; no second scene or exploration map. */
export function createHud(session:Session,panel:Panel,world:WorldScene,view:View,toggleMap:()=>void,threatControls:HTMLElement){
  const goal=el('section','ui-hud hud-goal'),place=el('div','hud-place'),title=el('h2'),next=el('p'),details=el('details'),summary=el('summary',undefined,'Why this next?'),detail=el('p');
  const locate=el('button',undefined,'Show location'),back=el('button',undefined,`Return to engineer (${shortcut('engineer')})`);
  details.append(summary,detail);goal.append(place,title,next,details,locate,back);goal.setAttribute('aria-label','Current objective');
  const time=el('section','ui-hud hud-time'),clock=el('strong'),warning=el('div','hud-warning'),speed=document.getElementById('speed-controls')!;
  time.setAttribute('aria-label','Time and defence');time.append(clock,speed,warning,threatControls);
  const pockets=el('section','ui-hud hud-engineer'),health=el('strong'),equipment=el('div'),stock=el('div'),inventory=el('button',undefined,`Inventory (${shortcut('pockets')})`);
  pockets.setAttribute('aria-label','Engineer');pockets.append(health,equipment,stock,inventory);inventory.onclick=()=>panel.togglePockets();
  const map=el('section','ui-hud hud-minimap'),fold=el('button',undefined,'Minimap'),mapButton=el('button',undefined,`Map (${shortcut('map')})`),canvas=el('canvas'),legend=el('div','hud-map-legend','● You  □ Known  ◆ Pin');
  canvas.width=180;canvas.height=140;canvas.setAttribute('role','img');canvas.setAttribute('aria-label','Known destinations and engineer');
  map.append(fold,mapButton,canvas,legend);mapButton.onclick=toggleMap;
  let expanded=window.innerWidth>=1100;const collapse=()=>{canvas.hidden=legend.hidden=!expanded;fold.setAttribute('aria-expanded',String(expanded));};fold.onclick=()=>{expanded=!expanded;collapse();};collapse();
  const prompt=el('div','hud-prompt');prompt.setAttribute('aria-label','Interaction');
  const hint=el('aside','ui-hud hud-opening-hint'),dismiss=el('button',undefined,'Dismiss hint');
  hint.append(el('span',undefined,`${shortcut('interact')} interacts · WASD moves · Build opens with ${shortcut('build')}. Find all controls in Help.`),dismiss);dismiss.onclick=()=>{hint.hidden=true;saveUiPreferences({dismissedHints:['opening']});};
  window.addEventListener('relight:preferences',()=>{hint.hidden=preferenceView.value.dismissedHints.includes('opening');});
  const track=el('section'),label=el('label',undefined,'Track one objective'),select=el('select');select.id='tracked-objective';label.htmlFor=select.id;track.append(label,select);
  document.querySelector('[data-adapter="projects"]')!.prepend(track);
  select.onchange=()=>{objectiveView.targetId=select.value==='auto'?undefined:select.value==='none'?null:select.value;};
  let action:NextAction|undefined,last=-Infinity,optionsKey='';
  locate.onclick=()=>{if(!action?.location)return;if(view.mode==='map')toggleMap();world.viewLocation(action.location.x,action.location.y);document.querySelector<HTMLCanvasElement>('#map > canvas')?.focus();panel.shell.sync();};
  back.onclick=()=>{if(view.mode==='map')toggleMap();world.returnToEngineer();document.querySelector<HTMLCanvasElement>('#map > canvas')?.focus();panel.shell.sync();};
  details.append(hint);
  for(const node of [goal,time,pockets,map]){document.getElementById('app')!.append(node);panel.shell.protect(node);}document.getElementById('app')!.append(prompt);
  // Cache only the existing terrain colours. Known destinations are refreshed from navigationTargets.
  const terrain=el('canvas');terrain.width=180;terrain.height=140;const ctx=terrain.getContext('2d')!,G=ground(session.state),scale=Math.min(180/G.tw,140/G.th),ox=(180-G.tw*scale)/2,oy=(140-G.th*scale)/2;
  ctx.fillStyle='#151d1e';ctx.fillRect(0,0,180,140);
  for(let py=0;py<140;py++)for(let px=0;px<180;px++){const x=Math.floor((px-ox)/scale),y=Math.floor((py-oy)/scale);if(x<0||y<0||x>=G.tw||y>=G.th)continue;const b=G.base[y*G.tw+x];ctx.fillStyle=b===T_RIVER?'#28465b':b===T_STREET?'#84908b':'#36494a';ctx.fillRect(px,py,1,1);}
  const put=(node:HTMLElement,text:string)=>{if(node.textContent!==text)node.textContent=text;};
  return {update(now:number){
    if(now-last<150)return;last=now;const st=session.state,e=st.engineer,c=campaignClock(st),tool=world.selectedTool(),targets=navigationTargets(st),discoveries=campaignDiscoveries(st);
    if(objectiveView.targetId&&!discoveries.some(s=>s.id===objectiveView.targetId))objectiveView.targetId=undefined;
    action=currentGoal(st,objectiveView.targetId).next;
    const bi=blockOfTile(st,Math.floor(e.x),Math.floor(e.y));put(place,bi>=0?blockName(st,bi):'City streets');
    const tracked=objectiveView.targetId!==null||e.down>=0;
    put(title,tracked?action?.title??'Explore':'No tracked objective');put(next,tracked?action?.text??'Choose a known destination':'Track a known objective in Projects.');put(detail,action?.detail??'');details.hidden=!tracked;locate.hidden=!tracked||!action?.location;back.hidden=!world.viewingThreat;
    const key=discoveries.map(s=>s.id+s.title).join('|');if(optionsKey!==key){optionsKey=key;select.replaceChildren(...[{id:'auto',title:'Automatic next action'},{id:'none',title:'Untrack'},...discoveries].map(s=>{const o=el('option',undefined,s.title);o.value=s.id;return o;}));}select.value=objectiveView.targetId===undefined?'auto':objectiveView.targetId===null?'none':objectiveView.targetId;
    put(clock,`Day ${c.day} · ${c.night?'Night':'Daylight'} · ${Math.floor(c.elapsed/60)}:${String(Math.floor(c.elapsed%60)).padStart(2,'0')} · ${st.speed===0?'Paused':`${st.speed}×`}`);
    const urgent=campaignAlerts(st)[0];put(warning,urgent?`${urgent.priority>=90?'⚠':'◷'} ${urgent.title}`:'');warning.title=urgent?.detail??'';time.classList.toggle('urgent',!!urgent&&urgent.priority>=60);time.classList.toggle('danger',!!urgent&&urgent.priority>=90);speed.inert=panel.shell.paused();
    inventory.textContent=`Inventory (${shortcut('pockets')})`;mapButton.textContent=`Map (${shortcut('map')})`;back.textContent=`Return to engineer (${shortcut('engineer')})`;
    (hint.firstChild as HTMLElement).textContent=`${shortcut('interact')} interacts · ${shortcut('north')}/${shortcut('west')}/${shortcut('south')}/${shortcut('east')} moves · ${shortcut('build')} opens Build. All controls are in Help.`;
    put(health,e.down>=0?`Engineer down · ${Math.ceil(Math.max(0,e.down-st.t))} s`:`Engineer · ${Math.ceil(e.hp)}/${ENGINEER_HP} HP`);
    put(equipment,e.truckSeat?'Driving truck':tool.tool==='hand'?'Empty hand':tool.tool==='rifle'?`Rifle · ${Math.floor((e.inv.magazine??0)*ROUNDS_PER_MAG)} rounds`:KIND_LABEL[tool.tool]);put(stock,`Pockets ${invStacks(e.inv)}/${INV_STACKS} stacks`);
    const interaction=view.mode==='world'&&!uiInput.blocked&&tool.tool==='hand'&&!tool.mode?world.interaction():null;
    put(prompt,(tool.tool!=='hand'||tool.mode)&&view.mode==='world'&&!uiInput.blocked?(tool.reason||`${tool.tool==='rifle'?'Hold left-click to fire':`${shortcut('rotate')} rotates`} · Escape cancels`):interaction?`${shortcut('interact')} · ${interaction.label}${interaction.reason?` · ${interaction.reason}`:''}`:'');prompt.hidden=!prompt.textContent;
    const placing=!!tool.point&&!!tool.reason&&(!!tool.mode||(tool.tool!=='hand'&&tool.tool!=='rifle'));prompt.classList.toggle('placement-prompt',placing);
    if(placing){prompt.style.left=`${Math.max(12,Math.min(window.innerWidth-344,tool.point![0]+24))}px`;prompt.style.top=`${Math.max(12,Math.min(window.innerHeight-hudInset.bottom-prompt.offsetHeight-12,tool.point![1]+24))}px`;}else{prompt.style.removeProperty('left');prompt.style.removeProperty('top');}
    if(preferenceView.value.dismissedHints.includes('opening')||st.t>0||invStacks(e.inv)>0||tool.tool!=='hand'||panel.shell.active())hint.hidden=true;
    map.hidden=!!panel.shell.active()||panel.shell.paused();goal.inert=pockets.inert=panel.shell.paused();hint.hidden=hint.hidden||panel.shell.paused();
    const paint=canvas.getContext('2d')!;if(expanded&&!map.hidden){paint.drawImage(terrain,0,0);for(const t of targets){paint.strokeStyle=t.kind==='pin'?'#e3b96f':'#f3ecdd';const x=ox+t.x*scale,y=oy+t.y*scale;if(t.kind==='pin'){paint.beginPath();paint.moveTo(x,y-3);paint.lineTo(x+3,y);paint.lineTo(x,y+3);paint.lineTo(x-3,y);paint.closePath();paint.stroke();}else paint.strokeRect(x-2,y-2,4,4);}paint.fillStyle='#92d8b5';paint.beginPath();paint.arc(ox+e.x*scale,oy+e.y*scale,3,0,Math.PI*2);paint.fill();paint.strokeStyle='#151d1e';paint.lineWidth=1;paint.stroke();canvas.setAttribute('aria-label',`Engineer and ${targets.length} known destinations: ${targets.map(t=>t.name).join(', ')}`);}
    document.documentElement.style.setProperty('--ui-clock-height',`${time.offsetHeight}px`);
    if(panel.shell.active())details.open=false;
    hudInset.top=Math.max(time.getBoundingClientRect().bottom,goal.getBoundingClientRect().bottom)+12;document.documentElement.style.setProperty('--ui-top-inset',`${time.offsetHeight+24}px`);
  }};
}
