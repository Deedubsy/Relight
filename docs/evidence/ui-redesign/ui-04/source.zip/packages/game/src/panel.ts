import {createInspectionPanel} from './inspectionPanel';
import {createInventoryPanel} from './inventoryPanel';
import {truckTransferPreview,handCraftCheck} from '@relight/sim';
import {createBuildPanel} from './buildPanel';
import { createUiShell, controlsHelp, el, type UiShell } from './uiShell';
import { createTruckWorkPanel } from './truckWorkPanel';
import { createBlueprintLibraryPanel } from './blueprintLibraryPanel';
import { createClipboardPanel, type ClipboardAction } from './clipboardPanel';
import { createCampaignGuide } from './campaignGuidePanel';
import { knownSite } from '@relight/sim';
import { truckDescription, truckBoardCheck, stationRoute } from '@relight/sim';
import { transportView, inspectionView } from './view';
/** DOM side panel: HUD, ring order (drag to reorder), stock + assembler, facilities, session summary, export. */
import { SimState, FrontEdgeView, ClaimInfo, HeldInfo, frontList, hud, facilityList, survivorList, shapeMetrics, clockOf, slotInfo, SKYLINE_RANGE, flowSummary, SHOT, MACHINE_COST,
  CHEST_ITEMS, ChestItem, chestCount, nearDepot, invStacks, INV_STACKS, KIT_STACKS, stackSize, REACH, Kind, CAMPAIGN_KINDS as KINDS, lockReason, survivorJoined, TURRET_RANGE, TURRET_HOPPER, LAMP_RADIUS,
  currentGoal, Goal, blockLabel, blockNameAt, edgeName, idxOf, activationCheck,
  machineAt, inReach, MACHINE_SIZE, projectList, describeProject, SUPPLY_CHEST_CAP, STOP_CAP, TRAM_CAP, TRAM_TPS, TRAM_DWELL_S, MACHINE_KW } from '@relight/sim';   // RI-05
import { Session, setSpeed, queue, shareUrl, dispatch, saveSlot, slotUrl, hasSlot, makeSessionSave } from './session';
import { buildCatalogue } from './buildCatalogue';
import { FACTORY_TEXT, FACTORY_STATUS_GLYPH } from './factoryStrings';
import { type Item, type OutputPriority, machineDimensions, routingDescription } from '@relight/sim';
import { inspectMachine, factoryStatistics, machineById, tramAt, RECIPE_IDS, ASSEMBLER_RECIPES, type RecipeId } from '@relight/sim';
import { shortcut, bound } from './controls';
import { debugView } from './view';
import { summarise, exportJson } from './telemetry';
import { hourReport } from '@relight/sim';
import { radioUpgradeCheck, campaignWarning, defenceDescription, repairCheck, CAMPAIGN_THREAT } from '@relight/sim';
import { turbineReachProblem, describeTurbine, campaignSite, describeSite, EXPANSION, SITE_IDS, SITE_LABELS, SiteId, districtGuidance, RECRUITS, recruitDescription, recruitCheck, discoveryDescription, discoveryCheck } from '@relight/sim';
import { ITEMS, StationRules, freightInbound, isCampaign, rulesetOf, CAMPAIGN_RULESET, LEGACY_RULESET, campaignClock } from '@relight/sim';

/** M6: what the export carries beside the telemetry — the command log (the replay's input) and, under the hour bot, its log and report. */
export function exportExtra(session: Session): Record<string, unknown> {
  return { commands: session.log, hour: session.hour ? hourReport(session.state, session.hour) : null };
}

export interface PanelHooks { onSelectEdge(id: number | null): void; onToggleView(): void; releaseInput(): void; cancelSelection(): boolean; selectedTool():string; locate(x:number,y:number):void; rotateTool():void; cancelTool():void }
/** D-B1-5: the build menu (key B) picks a building into the hand; the world scene installs the pick. */
export type BuildKind = Exclude<Kind, 'depot'>;

export interface Panel {
  shell: UiShell;
  update(nowMs: number): void;
  setSelectedEdge(e: FrontEdgeView | null): void;
  tooltip(info: ClaimInfo | HeldInfo | null, px: number, py: number): void;
  /** Plain lines (\n-separated) at a screen point; null hides. The world view's tile tooltip. */
  tooltipText(text: string | null, px: number, py: number): void;
  setView(mode: 'map' | 'world'): void;
  /** Show/hide the debug sections (stock, line, ring order, skyline, summary); returns the new visibility. */
  toggleDebug(): boolean;
  /** M1: show/hide the pockets and the Depot chest (Tab or I, or E on the Depot); returns the new visibility. */
  togglePockets(): boolean;
  /** RI-05: open the pockets targeted at the Supply chest or Tram stop at (x, y) (E on it): its transfers go there
   *  (chestTake / chestPut at). Tab / I target the Depot again. Pressing it on the same target closes them. */
  openPocketsAt(x: number, y: number): void;
  openTruck():void;
  openStationRoute(x:number,y:number):void;
  openRoutingAt(x:number,y:number):void;
  openInspectionAt(x:number,y:number):void;
  /** D-B1-5: show/hide the build menu (B); a click on a row puts that building in the hand. */
  toggleBuild(): boolean;
  /** Esc: close the pockets and the build menu. */
  closeAll(): void;
  onRemovalPreview: (() => import('@relight/sim').RemovalPreview|null) | null;
  onBlueprint: ((action: ClipboardAction) => void) | null;
  onPick: ((kind: BuildKind|'rifle') => void) | null;
  toast(msg: string, kind?: 'info' | 'bad' | 'good'): void;
}

const pct = (v: number) => `${Math.round(v * 100)} %`;
/** Pips are shape-coded as well as coloured (constitution, Phase 2): ● green, ▲ amber, ✕ red. Same shapes on the map. */
const PIP_GLYPH: Record<string, string> = { green: '●', amber: '▲', red: '✕' };
const f1 = (v: number) => (Math.round(v * 10) / 10).toFixed(1);
const f2 = (v: number) => (Math.round(v * 100) / 100).toFixed(2);

export function createPanel(session: Session, root: HTMLElement, hooks: PanelHooks): Panel {
  const st = session.state;
  const eco = st.config.economy;
  const flow = !!st.flow;
  const campaign = isCampaign(st);
  root.innerHTML = '';

  // header
  const header = el('section');
  const head = el('header');
  const mapName = st.city ? `${st.city.preset} city` : 'lattice';   // D6: the street-first city is the default map
  const h1 = el('h1', undefined, `Relight · map view · ${mapName} · seed ${st.seed}`);
  head.append(h1);
  if (session.scenario === 'B') head.append(el('span', 'badge', `Scenario B · from ${clockOf(session.startT)}`));
  const btnLink = el('button', undefined, 'Copy link');
  btnLink.title = 'Share this seed and settings';
  btnLink.onclick = () => {
    const url = shareUrl(session.params);
    navigator.clipboard?.writeText(url).then(() => toast('Link copied', 'good'), () => window.prompt('Copy this link', url));
  };
  const btnView = el('button', undefined, 'World view (M)');
  btnView.title = 'Toggle map ↔ world view at the same block (M, D5)';
  btnView.onclick = () => hooks.onToggleView();
  head.append(btnView, btnLink);
  header.append(head);
  const newSession = el('a', 'hint', campaign ? 'Open the legacy game in a new tab' : 'Try the cul-de-sac opening in a new tab');
  newSession.href = shareUrl({ ...session.params, state: null, autoplay: null, heart: false, stalker: false, flow: true, ruleset: campaign ? LEGACY_RULESET : CAMPAIGN_RULESET });
  newSession.target = '_blank'; newSession.rel = 'noopener'; header.append(newSession);
  // RI-02 (§11.2): the save / load baseline — slot 1 in this browser (Ctrl+S / Ctrl+O), beside the download below
  const saveRow = el('div', 'row');
  const btnSave = el('button', undefined, 'Save (Ctrl+S)');
  btnSave.title = 'Save the game to slot 1 in this browser: the state and every command so far. Load reloads the page from it, paused.';
  btnSave.onclick = () => saveGame();
  const btnLoad = el('button', undefined, 'Load (Ctrl+O)');
  btnLoad.title = 'Reload the page from slot 1 (the last Save in this browser). Unsaved progress is lost.';
  btnLoad.onclick = () => loadGame();
  const saveNote = el('span', 'hint', '');
  saveRow.append(btnSave, btnLoad, saveNote);
  header.append(saveRow);
  header.append(el('p', 'hint', campaign ? 'Explore from Home Court to the tram station. Carry materials and build local power to restore it, collect its tram kit, then restore the radio tower. Build walls and supplied turrets. E repairs damaged defences; major assaults begin on Night 3, with lighter raids between.' : 'Click a Dark block next to your territory to preview it (rot, front, wake bloom) — the map claims nothing. Claiming is on foot: string poles (7) to its substation, deliver the claim\'s steel and copper there (E), then E again on the substation to Activate. Held blocks facing Dark are ammo edges (red streets); their pips go ● ▲ ✕ as the hopper empties. Interior blocks (white rim) hold a machine slot. Press ` for the debug panel (stock, line, ring order, skyline, summary) and the block coordinates.'));
  root.append(header);
  function saveGame(): void {
    try {
      const save = saveSlot(session, '1');
      saveNote.textContent = `slot 1: ${clockOf(save.t)}`;
      toast(`Saved to slot 1 at ${clockOf(save.t)} (state ${save.hash}) — Ctrl+O or Load reloads it`, 'good');
    } catch (e) { toast(`Could not save: ${(e as Error).message}`, 'bad'); }
  }
  function loadGame(): void {
    if (!hasSlot('1', rulesetOf(st))) { toast('This campaign has no save yet — Ctrl+S saves it', 'bad'); return; }
    if (!window.confirm('Reload from slot 1? Unsaved progress is lost.')) return;
    location.href = slotUrl(session, '1');
  }
  if (hasSlot('1', rulesetOf(st))) saveNote.textContent = 'this campaign has a save';

  const guide=campaign?createCampaignGuide(session,root,c=>queue(session,c)):null;
  const clipboard=campaign?createClipboardPanel(session,root,a=>panelRef.onBlueprint?.(a),()=>panelRef.onRemovalPreview?.()??null):null;
  const blueprintLibrary=campaign?createBlueprintLibraryPanel(session,root,toast):null;
  const truckWork=campaign?createTruckWorkPanel(session,root,toast):null;
  if(guide){const discoveries=el('button',undefined,'Discoveries'),items=el('button',undefined,'Items and recipes');discoveries.onclick=()=>shell.open('projects');items.onclick=()=>shell.open('help');header.append(discoveries,items);}
  let radioUpgradeButton:HTMLButtonElement|null=null,defenceStatus:HTMLElement|null=null,defenceSection:HTMLElement|null=null;
  const coreButtons:{block:number;button:HTMLButtonElement;reason:HTMLElement}[]=[];
  if(campaign){const section=el('section');defenceSection=section;section.append(el('h2',undefined,'Base defence'));defenceStatus=el('p','hint');section.append(defenceStatus);
    radioUpgradeButton=el('button');radioUpgradeButton.onclick=()=>queue(session,{type:'upgradeRadio'});section.append(radioUpgradeButton);
    for(const base of [st.campaign!.homeBlock,st.campaign!.expansion!.station.block,st.campaign!.districts!.station.block]){const button=el('button',undefined,'Repair core');button.onclick=()=>{const core=session.state.campaign?.defence?.bases.find(b=>b.block===base);if(core)queue(session,{type:'repairDefence',x:core.x,y:core.y});};const reason=el('p','hint');coreButtons.push({block:base,button,reason});section.append(button,reason);}root.append(section);
  }
  // HUD
  const hudSec = el('section');
  hudSec.append(el('h2', undefined, campaign ? 'Home and production' : 'Territory'));
  const stats = el('div', 'stats');
  const mk = (label: string) => { const s = el('div', 'stat'); const b = el('b', 'mono', '0'); s.append(b, el('span', undefined, label)); stats.append(s); return { s, b }; };
  const sHeld = mk(campaign ? 'Bases' : 'Held'), sFront = mk('Front edges'), sInt = mk('Interior');
  const sProd = mk(campaign ? 'mag/min capacity' : 'mag/min made'), sDem = mk('mag/min demanded'), sStock = mk('magazines in stock');
  const sLost = mk('blocks lost'), sEmpty = mk('empty hoppers'), sClock = mk('sim clock');
  if (campaign) for (const stat of [sFront, sInt, sDem, sLost, sEmpty]) stat.s.remove();
  hudSec.append(stats);
  const speedRow = el('div', 'row'); speedRow.id='speed-controls';
  const speeds: [number, string][] = [[0, 'Pause'], [1, '1×'], [4, '4×'], [16, '16×']];
  const speedBtns = speeds.map(([m, label]) => { const b = el('button', undefined, label); b.onclick = () => setSpeed(session, m); speedRow.append(b); return { m, b }; });
  if(!campaign)speedRow.append(el('span', 'hint', FACTORY_TEXT.keys));
  hudSec.append(speedRow);
  root.append(hudSec);

  // M1 (D5): the pockets (40 stacks) and the Depot chest. Transfers need the engineer within reach of the Depot; the
  // sim refuses otherwise and the reason is toasted. Kits are free to draw (engineer.ts). Hidden until I.
  // GAME-ASSUMPTION (M1): a human is not auto-restocked the way the harness bot is (`restock` on standing at the HQ):
  // kits are taken here, one a claim, and a claim made with no kit in the pockets toasts that its edges wait.
  const pocketSec = el('section');
  pocketSec.hidden = true;
  let pocketAt: [number, number] | null = null;   // RI-05: the Supply chest or Tram stop the pockets talk to (E on it); null = the Depot
  let pocketId:number|null=null;
  const pocketTarget = () => campaign?(pocketId===null?undefined:machineById(session.state,pocketId)):pocketAt?machineAt(session.state,pocketAt[0],pocketAt[1]):undefined;
  const pocketWhere = () => { const m = pocketTarget(); return !m ? 'the Depot' : m.kind === 'tramstop' ? 'the Tram stop\'s platform' : 'the Supply chest'; };
  pocketSec.append(el('h2', undefined, FACTORY_TEXT.pocketTitle));
  const pocketHead = el('p', 'hint', '');
  pocketSec.append(pocketHead);
  const pocketList = el('ul', 'plain');
  const pocketRows = CHEST_ITEMS.map(item => {
    const l = el('li'), a = el('span', undefined, item === 'magazine' ? 'magazines' : item === 'kit' ? 'kits (10 stacks each)' : item), v = el('span', 'mono', '');
    const row = el('div', 'row');
    const n = item === 'kit' ? 1 : item === 'magazine' ? 5 : stackSize(item);
    const take = el('button', undefined, FACTORY_TEXT.take(n)), put = el('button', undefined, FACTORY_TEXT.putAll);
    take.onclick = () => { const r = dispatch(session, { type: 'factory', action: { type: 'chestTake', item, n, ...(pocketAt ? { x: pocketAt[0], y: pocketAt[1] } : {}) } }); if (r.moved) toast(`${r.moved} ${item} into the pockets`, 'good'); else toast(r.reason, 'bad'); };
    put.onclick = () => { const r = dispatch(session, { type: 'factory', action: { type: 'chestPut', item, n: 1e9, ...(pocketAt ? { x: pocketAt[0], y: pocketAt[1] } : {}) } }); if (r.moved) toast(`${r.moved} ${item} into ${pocketWhere()}`, 'good'); else toast(r.reason, 'bad'); };
    row.append(take, put);
    l.append(a, v); pocketList.append(l); pocketList.append(row);
    return { item: item as ChestItem, v, take, put };
  });
  // M2: machines picked up ride in the pockets as one stack each; they go down again from the hand (hotbar), never through the chest
  const pocketMach = el('li'); const pocketMachV = el('span', 'mono', 'none');
  pocketMach.append(el('span', undefined, 'machines carried (one stack each)'), pocketMachV); pocketList.append(pocketMach);
  pocketSec.append(pocketList);
  const freightForm = el('form', 'station-freight');
  freightForm.hidden = true;
  // Keep arrow keys and Space available to form controls instead of the game's keyboard capture.
  freightForm.addEventListener('keydown', event => event.stopPropagation());
  freightForm.append(el('h3', undefined, 'Station supply requests'));
  const freightStatus = el('p', 'hint');
  freightForm.append(freightStatus, el('p', 'hint', 'Request fills local stock up to a target. Export sends platform stock above Keep to other configured stations. Arrivals feed local belts. Configure both ends of a delivery.'));
  const freightTable = el('table'), freightHeader = el('tr');
  for (const label of ['Item', 'Request', 'Keep', 'Export']) freightHeader.append(el('th', undefined, label));
  freightTable.append(freightHeader);
  const freightRows = ITEMS.map(item => {
    const row = el('tr'); row.append(el('th', undefined, item));
    const request = el('input'), reserve = el('input'), exporting = el('input');
    for (const [input, label] of [[request, 'Request'], [reserve, 'Keep']] as const) {
      input.type = 'number'; input.min = '0'; input.max = String(STOP_CAP); input.step = '1'; input.required = true;
      input.setAttribute('aria-label', `${label} ${item}`);
    }
    exporting.type = 'checkbox'; exporting.setAttribute('aria-label', `Export ${item}`);
    for (const input of [request, reserve, exporting]) { const cell = el('td'); cell.append(input); row.append(cell); }
    freightTable.append(row);
    return { item, request, reserve, exporting };
  });
  const freightApply = el('button', undefined, 'Apply station requests'); freightApply.type = 'submit';
  freightForm.append(freightTable, freightApply);
  freightForm.onsubmit = event => {
    event.preventDefault();
    const target = pocketTarget();
    if (target?.kind !== 'tramstop' || !inReach(session.state, target.x, target.y, target.size) || !freightForm.reportValidity()) return;
    const rules: StationRules = {};
    for (const r of freightRows) rules[r.item] = { request: Number(r.request.value), reserve: Number(r.reserve.value), export: r.exporting.checked };
    queue(session, { type: 'setStationRules', x: target.x, y: target.y, rules });
    toast('Station requests queued', 'good');
  };
  let freightKey = '';
  pocketSec.append(freightForm);
  pocketSec.append(el('p', 'hint', campaign ? 'Take supplies from the house within reach. Build from carried steel and copper; right-click a machine to recover it and its contents. Restoration uses carried materials and local or connected power.' : `Pockets: ${INV_STACKS} stacks (a kit is ${KIT_STACKS}). The chest answers within ${REACH} tiles of the Depot. A claim's steel and copper go from the pockets into the block's substation (E on it) and are spent at Activate; its edges wait for a kit the engineer carries there. Machines are placed from the pockets: a carried one, else its price in carried steel and copper; right-click picks a machine up into the pockets with what it holds.`));
  root.append(pocketSec);

  // D-B1-5: the build menu (B). The hotbar (1–8) is its shortcut; 9 is the rifle. Prompt B M3: the Electricians'
  // three (0, [, ]) are listed locked, with who unlocks them, until the group's block turns Held (rule 8).
  let buildUi:ReturnType<typeof createBuildPanel>|null=null;
  const buildSec = el('section');
  buildSec.hidden = true;
  if(guide){const browse=el('button',undefined,'Browse items and recipes');browse.onclick=()=>guide.openItem();buildSec.append(browse);}
  buildSec.append(el('h2', undefined, `${FACTORY_TEXT.buildTitle} (${shortcut('build')})`));
  const buildList = el('ul', 'plain');
  const BUILD = campaign?[]:buildCatalogue(false);
  const buildCarried: { kind: BuildKind; v: HTMLElement; btn: HTMLButtonElement; lock: HTMLElement }[] = [];
  for (const b of BUILD) {
    const li = el('li'), btn = el('button', undefined, b.key ? `${b.key} · ${b.kind}` : b.kind) as HTMLButtonElement;
    const c = MACHINE_COST[b.kind];
    btn.title = FACTORY_TEXT.toolTitle(b.label, b.key);
    btn.onclick = () => panelRef.onPick?.(b.kind);
    const carried = el('span', 'mono', ''), lock = el('span', 'hint', '');
    li.append(btn, el('span', 'hint', ` ${FACTORY_TEXT.price(c.steel, c.copper, c.concrete)} · ${b.what} `), carried, lock);
    buildCarried.push({ kind: b.kind, v: carried, btn, lock });
    buildList.append(li);
  }
  // GAME-ASSUMPTION (M4): the Arsenal's rifle upgrade (§8, 1.4 s a crawler) is a toolbar entry only — the upgrade itself is outside the hour
  const mk2Lock = el('span', 'hint', '');
  const mk2 = el('li');mk2.hidden=campaign;
  mk2.append(el('span', 'mono', 'Rifle Mk2'), el('span', 'hint', ' · twin barrels, 1.4 s a crawler (the Mk1 takes 3 rounds, 2 s) '), mk2Lock);
  buildList.append(mk2);
  buildSec.append(buildList);
  const historyRow = el('div', 'row');
  for (const type of ['undoBuild', 'redoBuild'] as const) {
    const label = type === 'undoBuild' ? FACTORY_TEXT.undo : FACTORY_TEXT.redo;
    const button = el('button', undefined, `${label} (Ctrl+${shortcut(type === 'undoBuild' ? 'undo' : 'redo')})`);
    button.onclick = () => { const r = dispatch(session, { type }); toast(r.reason, r.ok ? 'good' : 'bad'); };
    historyRow.append(button);
  }
  buildSec.append(historyRow, el('p', 'hint', FACTORY_TEXT.pathHint), el('p', 'hint', FACTORY_TEXT.historyHint));
  buildSec.append(el('p', 'hint', FACTORY_TEXT.buildHelp));
  root.append(buildSec);

  const routingSec=el('section');routingSec.hidden=true;
  routingSec.setAttribute('aria-label',FACTORY_TEXT.inspectTitle);
  let inspectionId:number|null=null;
  let inspectionUi:ReturnType<typeof createInspectionPanel>|null=null,inventoryUi:ReturnType<typeof createInventoryPanel>|null=null;
  const inspectionHead=el('h2',undefined,FACTORY_TEXT.inspectTitle),inspectionBody=el('div','inspection-body');
  const recipeSelect=el('select');recipeSelect.setAttribute('aria-label',FACTORY_TEXT.recipeLabel);
  const recipeLabel=el('label',undefined,FACTORY_TEXT.recipeLabel+' ');recipeLabel.append(recipeSelect);
  for(const id of RECIPE_IDS){const option=el('option',undefined,ASSEMBLER_RECIPES[id].name);option.value=id;recipeSelect.append(option);}
  recipeSelect.onchange=()=>{const m=inspectionId===null?null:machineById(session.state,inspectionId);if(!m)return;const r=dispatch(session,{type:'factory',action:{type:'setRecipe',x:m.x,y:m.y,recipe:recipeSelect.value as RecipeId}});toast(r.reason,r.ok?'good':'bad');lastUpdate=-1e9;};
  let routingAt:[number,number]|null=null;
  const routingHead=el('p','hint',''),filterSelect=el('select'),prioritySelect=el('select');
  filterSelect.setAttribute('aria-label',FACTORY_TEXT.filter);prioritySelect.setAttribute('aria-label',FACTORY_TEXT.priority);
  for(const item of ['',...ITEMS]){const option=el('option',undefined,item||'Any item');option.value=item;filterSelect.append(option);}
  for(const priority of ['balanced','left','right']){const option=el('option',undefined,priority);option.value=priority;prioritySelect.append(option);}
  const filterLabel=el('label',undefined,FACTORY_TEXT.filter+' ');filterLabel.append(filterSelect);
  const priorityLabel=el('label',undefined,FACTORY_TEXT.priority+' ');priorityLabel.append(prioritySelect);
  const configure=()=>{
    const m=inspectionId===null?null:machineById(session.state,inspectionId);if(!m)return;const {x,y}=m;
    const r=dispatch(session,{type:'factory',action:{type:'routing',x,y,...(m.kind==='inserter'?{filter:filterSelect.value as Item||null}:{priority:prioritySelect.value as OutputPriority})}});
    toast(r.reason,r.ok?'good':'bad');lastUpdate=-1e9;
  };
  filterSelect.onchange=configure;prioritySelect.onchange=configure;
  routingSec.addEventListener('keydown',ev=>{ev.stopPropagation();if(bound('cancel',ev.key)){panelRef.closeAll();document.querySelector('canvas')?.focus();}});
  routingSec.append(inspectionHead,inspectionBody,recipeLabel,routingHead,filterLabel,priorityLabel,el('p','hint',FACTORY_TEXT.inspectHint));root.append(routingSec);
  const itemStats=el('details');itemStats.className='item-statistics';
  const statRows=el('tbody'),statWindow=el('p','hint'),table=el('table'),thead=el('thead'),statHeader=el('tr');
  for(const label of ['Item','Produced','Used','Made/min','Used/min'])statHeader.append(el('th',undefined,label));
  thead.append(statHeader);table.append(thead,statRows);
  itemStats.append(el('summary',undefined,FACTORY_TEXT.itemStats),statWindow,table,el('p','hint',FACTORY_TEXT.statsHint));root.append(itemStats);
  const statCells=ITEMS.map(item=>{const row=el('tr');row.append(el('th',undefined,item));const cells=Array.from({length:4},()=>el('td'));row.append(...cells);statRows.append(row);return cells;});
  const num=(n:number|null)=>n===null?'—':Number(n.toFixed(2)).toLocaleString();
  const windowText=(seconds:number)=>seconds>0?`Measured over the last ${num(seconds)} simulation seconds (up to 60 s).`:'Waiting for simulation time; no measured rate yet.';
  function openInspection(x:number,y:number):void {
    const m=tramAt(session.state,x,y)??machineAt(session.state,x,y);
    if(!m){toast('Point at a factory machine to inspect it');return;}
    transportView.stopId=m.kind==='tramstop'?m.id:null;
    shell.open('inspection');inspectionId=m.id;inspectionView.machineId=m.id;routingAt=[m.x,m.y];routingSec.hidden=false;lastUpdate=-1e9;update(performance.now());routingSec.scrollIntoView({block:'nearest'});
  }

  const truckOpen=el('button',undefined,'Truck cargo'),truckSec=el('section','truck-cargo');truckSec.hidden=true;
  const truckNote=el('p','hint'),truckStock=el('p'),truckPockets=el('p'),truckPreview=el('p','hint'),truckResult=el('p','action-result'),truckBoard=el('button',undefined,'Board truck');
  const truckItem=el('select');truckItem.setAttribute('aria-label','Truck cargo item');
  const truckCount=el('input');truckCount.type='number';truckCount.min='1';truckCount.step='1';truckCount.value='50';truckCount.setAttribute('aria-label','Truck cargo amount');
  const cargoRow=el('div','row'),loadCargo=el('button',undefined,'Load cargo'),unloadCargo=el('button',undefined,'Unload cargo');
  const cargoAction=(put:boolean)=>{const r=dispatch(session,{type:'factory',action:{type:'truckCargo',item:truckItem.value,n:Number(truckCount.value),put}});truckResult.textContent=r.reason;lastUpdate=-1e9;update(performance.now());};
  loadCargo.onclick=()=>cargoAction(true);unloadCargo.onclick=()=>cargoAction(false);
  truckBoard.onclick=()=>{const r=dispatch(session,{type:'factory',action:{type:'truckBoard'}});toast(r.reason,r.ok?'good':'bad');lastUpdate=-1e9;update(performance.now());};
  function openTruck():void {shell.open('truck');truckSec.hidden=false;lastUpdate=-1e9;update(performance.now());truckSec.scrollIntoView({block:'nearest'});}
  truckOpen.onclick=openTruck;truckOpen.hidden=!campaign;header.append(truckOpen);
  cargoRow.append(truckItem,truckCount,loadCargo,unloadCargo);
  truckSec.append(el('h2',undefined,'Truck cargo'),truckNote,truckBoard,truckPockets,truckStock,cargoRow,truckPreview,truckResult,el('p','hint','200 cargo stacks, separate from 40 pocket stacks. Load and unload within 8 tiles. E boards beside the truck or exits; WASD drives. Cargo stays parked when you leave. F on the truck opens this panel.'));root.append(truckSec);
  truckSec.addEventListener('keydown',ev=>{ev.stopPropagation();if(bound('cancel',ev.key)){panelRef.closeAll();document.querySelector('canvas')?.focus();}});
  const routeSec=el('section','station-route'),routeHead=el('h2'),routeNote=el('p','hint'),routeMap=el('button',undefined,'Show route on map'),routeClear=el('button',undefined,'Clear route');
  let panelMode:'map'|'world'='world';routeSec.hidden=true;
  routeMap.onclick=()=>{if(panelMode!=='map')hooks.onToggleView();};routeClear.onclick=()=>{transportView.stopId=null;routeSec.hidden=true;};
  routeSec.append(routeHead,routeNote,el('p','hint','Select a stop on the map to trace its existing track. Cyan: service connected. Amber: interruption. Circles: ready stops; crosses: unpowered; squares: full. Dots on track: trams.'),routeMap,routeClear);header.append(routeSec);

  // Rework Step 5: the side panel is held / front / interior / ammo made vs demanded / stock / blocks lost;
  // the rest sits behind the debug key (backquote) so a tester reads the map, not the panel.
  const debug = el('div', 'debug');
  debug.hidden = true;
  root.append(debug);

  // stock + assembler
  const stockSec = el('section');
  stockSec.append(el('h2', undefined, eco ? 'Rubble & production' : 'Production'));
  const stockList = el('ul', 'plain');
  const li = (label: string) => { const l = el('li'); const a = el('span', undefined, label); const v = el('span', 'mono', '0'); l.append(a, v); stockList.append(l); return v; };
  const vCu = eco ? li('Copper (wire)') : null, vSteel = eco ? li('Steel (frames)') : null, vStone = eco ? li('Stone (no use yet)') : null, vPatch = eco ? li('HQ steel patch left') : null;
  const vAsm = li('Assemblers');
  const vSlots = li('Machine slots used / free'), vRisk = li('Machines at risk (block back on the front)'), vDry = eco ? li('Blocks dug out (rubble gone)') : null;
  stockSec.append(stockList);
  const asmRow = el('div', 'row');
  const btnAsm = el('button', undefined, eco ? `Build assembler (${st.config.eco.assemblerCost.copper} Cu, ${st.config.eco.assemblerCost.steel} steel)` : 'Build assembler');
  btnAsm.title = st.config.startAsmRate !== null
    ? `The starting assembler makes ${st.config.startAsmRate} magazines per minute; each one you build makes ${st.config.asmRate}`
    : `Each assembler adds ${st.config.asmRate} magazines per minute`;
  btnAsm.onclick = () => queue(session, { type: 'addAssembler' });
  asmRow.append(btnAsm);
  // RI-01 (D-P4-5): under the tile line every Assembler is placed by hand; the block-level purchase is refused by the sim
  asmRow.hidden = flow;
  stockSec.append(asmRow);
  if (eco) stockSec.append(el('p', 'hint', `A claim costs ${st.config.eco.claimCost.steel} steel (5 frames) and ${st.config.eco.claimCost.copper} Cu (10 wire), delivered from the pockets to the block's substation and spent once at Activate — nothing is charged from the map. A magazine costs ${st.config.eco.magazineCost.steel} steel + ${st.config.eco.magazineCost.copper} Cu (§12); assemblers stop when the stock runs out. Held blocks yield their district's rubble: civic stone, residential copper, industrial steel.`));
  debug.append(stockSec);

  // M2: the tile line on the HQ lot (world view). Counts and rates come from flowSummary; the Craft button queues a
  // hand craft (§11) at the workbench, from the pockets into the pockets (prompt B M2).
  const lineSec = el('section');
  let vMach: HTMLElement | null = null, vBeltItems: HTMLElement | null = null, vLineRate: HTMLElement | null = null, vLineMade: HTMLElement | null = null,
      vHand: HTMLElement | null = null, vBuffer: HTMLElement | null = null, vCoal: HTMLElement | null = null, vCrafts: HTMLElement | null = null,
      vPower: HTMLElement | null = null, vGens: HTMLElement | null = null, vTurrets: HTMLElement | null = null, vLamps: HTMLElement | null = null, vBrown: HTMLElement | null = null;
  let btnCraft: HTMLButtonElement | null = null;
  if (flow) {
    lineSec.append(el('h2', undefined, 'Line on the HQ lot (world view)'));
    const lineList = el('ul', 'plain');
    const li2 = (label: string) => { const l = el('li'); const a = el('span', undefined, label); const v = el('span', 'mono', '0'); l.append(a, v); lineList.append(l); return v; };
    vMach = li2('Excavators / belts / inserters / Assemblers'); vBeltItems = li2('Items on belts'); vLineRate = li2('Line mag/min (assemblers crafting now)');
    vLineMade = li2('Magazines made by the line'); vHand = li2('Mined / crafted by hand'); vBuffer = li2('Magazines in the line buffer'); vCoal = li2('Coal (Depot + Generators)'); vCrafts = li2('Hand crafts queued');
    // M3: power as one number (§14), the Generators, the turrets' hoppers, the lights
    vPower = li2('Power: load / supply kW (demand)'); vGens = li2('Generators burning / built'); vTurrets = li2('Turret rounds / capacity · on belts');
    vLamps = li2('Lamps lit / built · poles connected'); vBrown = li2('Brownout seconds · machines running at %');
    lineSec.append(lineList);
    const craftRow = el('div', 'row');
    btnCraft = el('button', undefined, `Craft a magazine by hand (${SHOT.inputs.steel} steel + ${SHOT.inputs.copper} Cu, ${SHOT.seconds} s)`);
    btnCraft.title = 'E on the workbench in the world view. A hand craft takes its steel and copper from the pockets and puts the magazine in the pockets; the engineer stays within reach of the Depot while it runs.';
    btnCraft.onclick = () => { const r = dispatch(session, { type: 'factory', action: { type: 'craft', item: 'magazine', count: 1 } }); toast(r.reason, r.ok ? 'good' : 'bad'); };
    craftRow.append(btnCraft);
    lineSec.append(craftRow);
    const mc = MACHINE_COST;
    lineSec.append(el('p', 'hint', `World view: the hotbar 1–8 is the build menu's shortcut (B lists the buildings and their costs), 9 the rifle. R rotate, Q pipette / clear the hand, right-click picks a machine up into the pockets with an empty hand. C / L / H / V put the Supply chest, Track, Tram stop and Tram in the hand (the kit once the rail yard is restored; RI-05). WASD moves (Shift sprints, Space dodges); hand actions reach ${REACH} tiles. Hold the left button on rubble with an empty hand to mine it a unit a second into the pockets; E on the workbench crafts a magazine (${SHOT.inputs.steel} steel + ${SHOT.inputs.copper} Cu, ${SHOT.seconds} s). Magazines reach the ring only through the Depot: belt or inserter them into it, or carry them (Tab / I). With ?heart=1 (RI-06, a candidate) the rail yard's claim is the Junction Heart: string poles to and E-deliver the two feeder cabinets as well as the substation, Start there, keep both feeders powered — E repairs a knocked-out cabinet, X aborts.`));
    debug.append(lineSec);
  }

  // ring order
  const ringSec = el('section');
  ringSec.append(el('h2', undefined, 'Ammo ring order — drag to reorder'));
  const ring = el('ol', 'ring');
  ringSec.append(ring);
  const ringHint = el('p', 'hint', 'Edges fill from the top. The last edges starve first when production falls short. Pips: ● hopper at least half full · ▲ running low · ✕ empty, blinking.');
  ringSec.append(ringHint);
  debug.append(ringSec);

  // facilities (§8: silhouettes within SKYLINE_RANGE blocks of a Held block) and survivors (§8: a block's contents
  // show once a neighbour is Held)
  const facSec = el('section'); facSec.hidden=campaign; // Campaign discoveries have explicit local recruitment; this is legacy debugging.
  facSec.append(el('h2', undefined, 'Skyline'));
  const facList = el('ul', 'plain');
  facSec.append(facList);
  facSec.append(el('p', 'hint', `A facility shows once it is within ${SKYLINE_RANGE} blocks of a Held block; survivors show once a block next to them is Held, and join when their block is.`));
  const survList = el('ul', 'plain');
  facSec.append(el('h2', undefined, 'Survivors'), survList);
  // RI-05 (plan §5.3): the neighbourhood projects — stage, what each still needs, its reward once restored
  const projList = el('ul', 'plain');
  facSec.append(el('h2', undefined, 'Projects'), projList, el('p', 'hint', 'A neighbourhood project (the rail yard\'s restoration first, its reward the rail kit; a local supply depot at a Supply chest). Deliveries by hand (E) or by belt; the rail yard\'s commissioning is its block\'s Activate, the depot\'s is E at its chest once its materials are in it.'));
  debug.append(facSec);

  // summary
  const sumSec = el('section', 'summary');
  sumSec.append(el('h2', undefined, 'Session summary'));
  const dl = el('dl');
  const dd = (label: string) => { dl.append(el('dt', undefined, label)); const d = el('dd', undefined, '–'); dl.append(d); return d; };
  const dTime = dd(session.scenario === 'B' ? 'Sim time (session from ' + clockOf(session.startT) + ')' : 'Sim time'), dClaims = dd('Claims this session (per hour)'), dShape = dd('Bounding box'), dRatio = dd('Perimeter / area'),
        dAmmo = dd('Ammo spent'), dLost = dd('Blocks lost'), dReorder = dd('Ring reorders'), dEncl = dd('First enclosure');
  sumSec.append(dl);
  const sumRow = el('div', 'row');
  const btnExport = el('button', undefined, 'Export telemetry JSON');
  btnExport.onclick = () => {
    const json = exportJson(session.telemetry, session.state, exportExtra(session));
    const blob = new Blob([json], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `relight-seed${st.seed}-${clockOf(st.t).replace(/:/g, '')}.json`;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast('Telemetry exported', 'good');
  };
  sumRow.append(btnExport);
  const btnState = el('button', undefined, 'Download save');
  btnState.title = 'Download a save file (the state and the command log); load it later with ?state=<file url>';
  btnState.onclick = () => {
    const blob = new Blob([JSON.stringify(makeSessionSave(session))], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `relight-state-seed${st.seed}-${clockOf(session.state.t).replace(/:/g, '')}.json`;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast('Save file downloaded', 'good');
  };
  sumRow.append(btnState);
  sumSec.append(sumRow);
  debug.append(sumSec);

  // tooltip + toasts
  const tip = document.getElementById('tooltip')!;
  const toasts = document.getElementById('toasts')!;
  function toast(msg: string, kind: 'info' | 'bad' | 'good' = 'info'): void {
    const t = el('div', `toast ${kind === 'info' ? '' : kind}`, msg);
    toasts.append(t);
    while (toasts.children.length > 6) toasts.firstElementChild?.remove();
    setTimeout(() => t.remove(), 5000);
  }

  // ring list rendering with drag/drop
  let dragging: number | null = null;
  let ringKey = '';
  let selected: number | null = null;
  function renderRing(edges: FrontEdgeView[]): void {
    const key = edges.map(e => `${e.id}:${e.pip}:${Math.round(e.level * 20)}`).join(',') + `|${selected}|${debugView.coords}`;
    if (key === ringKey || dragging !== null) return;
    ringKey = key;
    ring.innerHTML = '';
    for (const e of edges) {
      const l = el('li');
      l.draggable = true;
      l.dataset.id = String(e.id);
      if (e.id === selected) l.classList.add('selected');
      // RI-02: the street's name (names.ts); the block coordinates only behind the ` toggle
      const where = debugView.coords ? `(${e.from.x},${e.from.y}) → (${e.to.x},${e.to.y})  ${e.darkDistrict}` : edgeName(session.state, e.id);
      l.append(el('span', 'pos', String(e.ringPos + 1)), el('span', `pip ${e.pip}`, PIP_GLYPH[e.pip]), el('span', 'mono', where), el('span', 'lvl', pct(e.level)));
      l.title = `Dark side rot ${pct(e.darkRot)}${e.darkWell ? ' · well' : ''}`;
      l.onclick = () => { hooks.onSelectEdge(selected === e.id ? null : e.id); };
      l.ondragstart = ev => { dragging = e.id; ev.dataTransfer?.setData('text/plain', String(e.id)); };
      l.ondragend = () => { dragging = null; clearMarks(); ringKey = ''; };
      l.ondragover = ev => {
        ev.preventDefault();
        const r = l.getBoundingClientRect();
        clearMarks();
        l.classList.add(ev.clientY < r.top + r.height / 2 ? 'drop-before' : 'drop-after');
      };
      l.ondrop = ev => {
        ev.preventDefault();
        if (dragging === null) return;
        const r = l.getBoundingClientRect();
        const before = ev.clientY < r.top + r.height / 2;
        const ids = frontList(session.state).map(x => x.id).filter(id => id !== dragging);
        let at = ids.indexOf(e.id);
        if (at < 0) at = ids.length; else if (!before) at += 1;
        ids.splice(at, 0, dragging);
        queue(session, { type: 'ringOrder', ids });
        dragging = null; clearMarks(); ringKey = '';
      };
      ring.append(l);
    }
    if (!edges.length) ring.append(el('li', undefined, 'no front'));
  }
  function clearMarks(): void { for (const c of Array.from(ring.children)) c.classList.remove('drop-before', 'drop-after'); }

  // RI-02 (§11.2, D-GB-2 (a), rule 8): the current-goal line over the canvas — goal.ts `currentGoal` read off the
  // state once a sim second; the goal text and its reason, and the shortage line under it while something is short.
  const goalEl = document.getElementById('goal')!;
  const goalText = goalEl.querySelector('.goal-text')!, goalWhy = goalEl.querySelector('.goal-why')!, goalSupport = goalEl.querySelector('.goal-support') as HTMLElement;
  let goalSecond = -1, goalKey = '';
  function updateGoal(s: SimState): void {
    if(s.campaign){goalEl.hidden=true;return;}
    const sec = Math.floor(s.t);
    if (sec === goalSecond) return;
    goalSecond = sec;
    const g: Goal = currentGoal(s);
    const key = `${g.goal.id}|${g.goal.text}|${g.goal.why}|${g.support ? `${g.support.id}|${g.support.text}` : ''}`;
    if (key === goalKey) return;
    goalKey = key;
    goalText.textContent = g.goal.text; goalWhy.textContent = g.goal.why;
    goalSupport.textContent = g.support ? `${g.support.text} — ${g.support.why}` : '';
    goalSupport.hidden = !g.support;
    goalEl.hidden = false;
  }
  let lastUpdate = -1e9;
  let lastFacKey = '';
  function update(nowMs: number): void {
    if (nowMs - lastUpdate < 150) return;
    lastUpdate = nowMs;
    const s: SimState = session.state;
    const route=transportView.stopId===null?null:stationRoute(s,transportView.stopId);routeSec.hidden=!route;
    if(route){routeHead.textContent=`Selected stop ${route.stop.id}`;routeNote.textContent=route.summary;}else transportView.stopId=null;
    if(!truckSec.hidden){
      truckNote.textContent=truckDescription(s);truckBoard.textContent=s.engineer.truckSeat?'Exit truck':'Board truck';truckBoard.title=truckBoardCheck(s);
      const keys=[...new Set([...ITEMS,...Object.keys(s.engineer.inv),...Object.keys(s.campaign?.truck?.cargo??{})])].sort(),selected=truckItem.value;
      if(Array.from(truckItem.options).map(o=>o.value).join('|')!==keys.join('|')){truckItem.replaceChildren(...keys.map(k=>{const o=el('option',undefined,k);o.value=k;return o;}));if(keys.includes(selected))truckItem.value=selected;else truckItem.value='steel';}
      truckPockets.textContent=`Pockets: ${Object.entries(s.engineer.inv).filter(([,n])=>n>0).map(([k,n])=>`${k} ${num(n)}`).join(', ')||'empty'}`;
      truckStock.textContent=`Truck cargo: ${Object.entries(s.campaign?.truck?.cargo??{}).filter(([,n])=>n>0).map(([k,n])=>`${k} ${num(n)}`).join(', ')||'empty'}`;
      const load=truckTransferPreview(s,truckItem.value,Number(truckCount.value),true),unload=truckTransferPreview(s,truckItem.value,Number(truckCount.value),false);
      truckPreview.textContent=`Load: ${load.ok?`${load.moved} available`:load.reason} · Unload: ${unload.ok?`${unload.moved} available`:unload.reason}`;
      loadCargo.setAttribute('aria-disabled',String(!load.ok));unloadCargo.setAttribute('aria-disabled',String(!unload.ok));
    }
    if(!routingSec.hidden&&inspectionId!==null){
      const m=machineById(s,inspectionId),info=inspectMachine(s,inspectionId),valid=m&&(m.kind==='inserter'||m.kind==='splitter');
      routingAt=m?[m.x,m.y]:null;
      inspectionHead.textContent=info?`${FACTORY_TEXT.inspectTitle} · ${info.title}`:'Inspected machine removed';
      if(!campaign)inspectionBody.replaceChildren();
      if(info&&!campaign){
        const line=(text:string,cls='hint')=>inspectionBody.append(el('p',cls,text));
        const glyph=FACTORY_STATUS_GLYPH[info.status.state];
        line(`${glyph} ${info.status.state} — ${info.status.reason}`,'machine-status');line(info.location);
        const p=info.circuit;
        line(`${p.scope}: ${num(p.supply)} kW supply / ${num(p.demand)} kW demand · ${num(p.load)} kW load · ${num(p.throttle*100)}% throttle`);
        line(`Machine draw: ${info.draw} kW${info.draw===0?' · independent of power throttle':''}`);
        if(info.recipe)line(`Recipe: ${info.recipe}`);
        for(const r of info.nominal)line(`${r.item}: nominal ${num(r.input)} in / ${num(r.output)} out per min · power-limited ${num(r.input*info.scale)} in / ${num(r.output*info.scale)} out per min`);
        if(info.capacity)line(info.capacity);
        if(info.measured){line(`${info.measurement}. ${windowText(info.measured.seconds)}`);for(const r of info.measured.rows)if(r.produced>0||info.nominal.some(n=>n.item===r.item&&n.output>0))line(`${r.item}: ${num(r.produced)} recorded · ${num(r.producedPerMin)}/min measured`);}
        line(info.contents.length?'Contents':'Contents: empty');
        for(const c of info.contents)line(`${c.place} · ${c.item}: ${num(c.count)}`);
        for(const setting of info.settings)line(setting);
        if(info.range)line(info.range);
        if(!info.reachable)line('Out of reach — walk closer to change settings.');
      }
      recipeLabel.hidden=m?.kind!=='assembler';recipeSelect.disabled=!info?.reachable;
      if(info&&document.activeElement!==recipeSelect)recipeSelect.value=info.recipeId;
      routingHead.hidden=!valid;routingHead.textContent=valid?routingDescription(s,m):'';
      filterLabel.hidden=m?.kind!=='inserter';priorityLabel.hidden=m?.kind!=='splitter';
      filterSelect.disabled=prioritySelect.disabled=!valid||!inReach(s,m!.x,m!.y,...machineDimensions(m!));
      if(valid){filterSelect.value=m.filter??'';prioritySelect.value=m.priority??'balanced';}
    }
    if(itemStats.open){const stats=factoryStatistics(s);if(stats){statWindow.textContent=windowText(stats.seconds);stats.rows.forEach((r,i)=>[r.produced,r.consumed,r.producedPerMin,r.consumedPerMin].forEach((n,j)=>{statCells[i][j].textContent=num(n);}));}}
    inspectionUi?.update();if(!pocketSec.hidden)inventoryUi?.update();
    updateGoal(s);
    if(defenceStatus)defenceStatus.textContent=campaignWarning(s);
    if(radioUpgradeButton){radioUpgradeButton.hidden=!knownSite(s,'radio');const why=radioUpgradeCheck(s);radioUpgradeButton.disabled=!!why;radioUpgradeButton.title=why||'Add approach direction and broad composition to received warnings';radioUpgradeButton.textContent=s.campaign?.defence?.radioUpgrade?'Radio precision upgraded':`Upgrade radio (${CAMPAIGN_THREAT.radioUpgradeSteel} steel + ${CAMPAIGN_THREAT.radioUpgradeCopper} copper)`;}
    for(const row of coreButtons){const core=s.campaign?.defence?.bases.find(b=>b.block===row.block);row.button.hidden=!core;const why=core?repairCheck(s,core.x,core.y):'';row.button.disabled=!core||!!why;row.button.title=why||'';row.reason.textContent=why||'';row.reason.hidden=!core||!why;if(core)row.button.textContent=defenceDescription(s,core.x,core.y);}
    buildUi?.update();guide?.update();clipboard?.update();blueprintLibrary?.update();truckWork?.update();
    const h = hud(s);
    sHeld.b.textContent = String(h.held); sFront.b.textContent = String(h.front); sInt.b.textContent = String(h.interior);
    const fs = flowSummary(s);
    const prod = h.ammo.productionMagPerMin + fs.productionMagPerMin;   // block-level assemblers plus the tile line
    sProd.b.textContent = f1(prod); sDem.b.textContent = f1(h.ammo.demandMagPerMin1);
    sDem.s.classList.toggle('warn', h.ammo.demandMagPerMin1 > prod + 1e-9);
    sStock.b.textContent = f1(h.ammo.stockMags); sLost.b.textContent = String(h.lost);
    sEmpty.b.textContent = String(h.ammo.emptyHoppers); sEmpty.s.classList.toggle('warn', h.ammo.emptyHoppers > 0);
    sClock.b.textContent = h.clock;
    if (campaign) { const clock = campaignClock(s); sClock.b.textContent = `Day ${clock.day} · ${clock.night ? 'night' : 'daylight'}`; }
    for (const { m, b } of speedBtns) b.classList.toggle('active', s.speed === m);
    projList.replaceChildren(...projectList(s).map(r => el('li', undefined, describeProject(s, r))));   // RI-05
    if (!pocketSec.hidden) {
      // RI-05: a targeted chest or stop that was picked up or lost sends the pockets back to the Depot
      const tgt = pocketTarget();
      if (!campaign && pocketAt && (!tgt || (tgt.kind !== 'chest' && tgt.kind !== 'tramstop'))) pocketAt = null;
      const e = s.engineer, near = pocketAt ? !!tgt&&inReach(s,tgt.x,tgt.y,MACHINE_SIZE[tgt.kind]) : nearDepot(s), where = pocketWhere();
      pocketHead.textContent = `${invStacks(e.inv)} / ${INV_STACKS} stacks · ${near ? `at ${where}` : `walk to ${where} to transfer (${REACH} tiles)`}${pocketAt && tgt ? ` · ${tgt.kind === 'tramstop' ? `platform ${Object.values(tgt.inv).reduce((a, b) => a + b, 0)} / ${STOP_CAP}` : `${Object.values(tgt.inv).reduce((a, b) => a + b, 0)} / ${SUPPLY_CHEST_CAP}`}` : ''} · HP ${Math.round(e.hp)}`;
      for (const r of pocketRows) {
        const c = pocketAt && tgt ? ((tgt.kind === 'tramstop' ? tgt.cargo : tgt.inv)?.[r.item] ?? 0) : chestCount(s, r.item);
        r.v.textContent = `pockets ${e.inv[r.item] ?? 0} · ${pocketAt && tgt?.kind === 'tramstop' ? `platform ${tgt.inv[r.item] ?? 0} · arrivals` : pocketAt ? 'there' : 'chest'} ${c === Infinity ? '∞' : c}`;
        r.take.disabled = !near || c <= 0; r.put.disabled = !near || !(e.inv[r.item] > 0);
      }
      const mach = KINDS.filter(k => (e.inv[k] ?? 0) > 0).map(k => `${e.inv[k]} ${k}`);
      pocketMachV.textContent = mach.length ? mach.join(', ') : 'none';
      freightForm.hidden = !pocketAt || tgt?.kind !== 'tramstop';
      if (!freightForm.hidden && tgt) {
        const key = `${tgt.id}:${JSON.stringify(tgt.freight)}`;
        if (key !== freightKey) {
          freightKey = key;
          for (const r of freightRows) {
            r.request.value = String(tgt.freight?.[r.item]?.request ?? 0);
            r.reserve.value = String(tgt.freight?.[r.item]?.reserve ?? 0);
            r.exporting.checked = tgt.freight?.[r.item]?.export ?? false;
          }
        }
        freightStatus.textContent = `${tgt.freight ? 'Requests active' : 'Not configured — applying requests enables selective freight on this line'} · ${freightInbound(s, tgt.id)} items reserved in transit`;
        freightApply.disabled = !near;
      } else freightKey = '';
    }
    if (!buildSec.hidden) for (const b of buildCarried) {
      const n = s.engineer.inv[b.kind] ?? 0; b.v.textContent = FACTORY_TEXT.carried(n);
      const lk = lockReason(s, b.kind); b.btn.disabled = !!lk; if(lk)b.btn.title=lk; b.lock.textContent = FACTORY_TEXT.locked(lk);
    }
    if (!buildSec.hidden) mk2Lock.textContent = survivorJoined(s, 'Arsenal') ? '· the Arsenal are in — the upgrade itself is outside the hour (prompt B M4)' : '· locked: the Arsenal unlock it — hold their block';
    if (vCu) { vCu.textContent = String(Math.floor(s.stock.copper)); vSteel!.textContent = String(Math.floor(s.stock.steel)); vStone!.textContent = String(Math.floor(s.stock.stone)); vPatch!.textContent = String(Math.floor(s.patch.steel)); }
    vAsm.textContent = String(h.ammo.assemblers);
    const si = slotInfo(s);
    vSlots.textContent = `${si.used} / ${si.free}`; vRisk.textContent = String(si.atRisk); if (vDry) vDry.textContent = String(si.dry);
    const broke = eco && (s.stock.copper < s.config.eco.assemblerCost.copper || s.stock.steel < s.config.eco.assemblerCost.steel);
    btnAsm.disabled = broke || si.free === 0;
    btnAsm.title = si.free === 0 ? 'No free machine slot: an assembler needs an Interior block (every neighbour Held or inert). Enclose a block to get one.'
      : broke ? 'Not enough rubble' : `Goes on ${blockLabel(s, idxOf(s, si.next!.x, si.next!.y), debugView.coords)}; makes ${s.config.asmRate} magazines per minute`;
    if (vMach && s.flow) {
      vMach.textContent = `${fs.excavators} / ${fs.belts} / ${fs.inserters} / ${fs.assemblers}`; vBeltItems!.textContent = String(fs.beltItems);
      vLineRate!.textContent = f1(fs.productionMagPerMin); vLineMade!.textContent = String(fs.magsMade);
      vHand!.textContent = `${s.flow.stats.handMined} / ${s.flow.stats.handCrafted}`;
      vBuffer!.textContent = `${Math.floor(s.buffer / SHOT.count)} / ${Math.floor(s.config.bufferCap / SHOT.count)}`; vCoal!.textContent = String(Math.floor(fs.coal)); vCrafts!.textContent = String(fs.craftsQueued);
      btnCraft!.disabled = !!handCraftCheck(s).reason;
      vPower!.textContent = `${Math.round(fs.loadKw)} / ${Math.round(fs.supplyKw)} (${Math.round(fs.demandKw)})`; vPower!.parentElement!.classList.toggle('warn', fs.demandKw > fs.supplyKw + 1e-9);
      vGens!.textContent = `${fs.generatorsBurning} / ${fs.generators}`; vGens!.parentElement!.classList.toggle('warn', fs.generators > 0 && fs.generatorsBurning === 0);
      vTurrets!.textContent = `${Math.round(fs.turretRounds)} / ${fs.turretCap} · ${fs.beltAmmo}`; vTurrets!.parentElement!.classList.toggle('warn', fs.turrets > 0 && fs.turretRounds === 0);
      vLamps!.textContent = `${fs.lampsLit} / ${fs.lamps} · ${fs.polesConnected} / ${fs.poles}`;
      vBrown!.textContent = `${Math.round(fs.brownoutS)} · ${Math.round(fs.throttle * 100)} %`; vBrown!.parentElement!.classList.toggle('warn', fs.throttle < 1 - 1e-9);
    }
    renderRing(frontList(s));
    const facs = facilityList(s).filter(f => f.visible);
    const survs = survivorList(s).filter(f => f.revealed);
    const fk = facs.map(f => `${f.name}${f.held ? 1 : 0}`).join() + '|' + survs.map(f => `${f.tag}${f.held ? 1 : 0}`).join() + `|${debugView.coords}`;
    if (fk !== lastFacKey) {
      lastFacKey = fk; facList.innerHTML = ''; survList.innerHTML = '';
      // RI-02: facilities and survivors by their block's name (names.ts); the coordinates only behind the ` toggle
      const at = (x: number, y: number) => blockLabel(s, idxOf(s, x, y), debugView.coords);
      for (const f of facs) { const l = el('li'); l.append(el('span', undefined, `${f.name} · ${at(f.x, f.y)}`), el('span', f.held ? '' : 'muted', f.held ? 'reached' : `${f.dist} blocks from HQ`)); facList.append(l); }
      if (!facs.length) facList.append(el('li', 'muted', 'nothing on the skyline yet'));
      // Phase 7 (STANDARDS dealbreaker 1): from minute one the panel says where blueprints and copy-paste will come from.
      // GAME-ASSUMPTION (GA-EF-3): the row is a fixed line of text ("not yet found"), not a survivor the sim knows; Phase 7
      // replaces it with the real survivor's row and the §8 gift
      if(!campaign){ const l = el('li'); l.append(el('span', undefined, 'Blueprints and copy-paste · Foreman tools'), el('span', 'muted', 'available in the exploration campaign')); survList.append(l); }
      for (const f of survs) { const l = el('li'); l.append(el('span', undefined, `${f.tag} · ${f.name} · ${at(f.x, f.y)}`), el('span', f.held ? '' : 'muted', f.held ? 'with us' : 'seen')); survList.append(l); }
      if (!survs.length) survList.append(el('li', 'muted', 'no one else found yet'));
    }
    const sum = summarise(session.telemetry, s);
    dTime.textContent = sum.simTime;
    dClaims.textContent = `${sum.claims} (${f1(sum.claimsPerHour)}/h)`;
    dShape.textContent = `${sum.shape.bbox.w}×${sum.shape.bbox.h}, aspect ${f2(sum.shape.bbox.aspect)}`;
    dRatio.textContent = f2(sum.shape.perimeterOverArea);
    dAmmo.textContent = `${Math.round(sum.ammoSpentMags)} mags, ${Math.round(sum.shellsSpent)} shells`;
    dLost.textContent = String(sum.lost);
    dReorder.textContent = String(sum.reorders);
    dEncl.textContent = sum.firstEnclosure;
  }

  function tooltipText(text: string | null, px: number, py: number): void {
    if (!text) { tip.hidden = true; return; }
    tip.innerHTML = '';
    text.split('\n').forEach((line, i) => tip.append(el('div', i ? 'muted' : undefined, line)));
    tip.hidden = false;
    const w = tip.offsetWidth, h = tip.offsetHeight;
    tip.style.left = `${Math.max(12, Math.min(px + 14, window.innerWidth - w - 12))}px`; tip.style.top = `${Math.max(12, Math.min(py + 14, window.innerHeight - h - 12))}px`;
  }
  function setView(mode: 'map' | 'world'): void {
    panelMode=mode;
    h1.textContent = `Relight · ${mode} view · ${mapName} · seed ${st.seed}`;
    btnView.textContent = mode === 'map' ? 'World view (M)' : 'Map view (M)';
  }

  function tooltip(info: ClaimInfo | HeldInfo | null, px: number, py: number): void {
    if (!info) { tip.hidden = true; return; }
    if (campaign) {
      tooltipText(`${blockLabel(session.state, idxOf(session.state, info.x, info.y), debugView.coords)}\n${'held' in info ? 'Home base: build with supplies from the house.' : 'Explore on foot. Restore the tram installation with carried materials and power.'}`, px, py);
      return;
    }
    if ('held' in info) {
      const slot = info.slot === 'free' ? 'machine slot free' : info.slot === 'assembler' ? 'assembler here' : info.slot === 'Mk1' ? 'HQ: Mk1 assembler'
        : info.slot === 'at risk' ? 'assembler AT RISK: block is back on the front' : 'front block: slot taken by the defence ring';
      const rubble = info.district === 'out' ? 'no rubble (outskirts)' : info.poolLeft > 0 ? `rubble left ${Math.floor(info.poolLeft)} (${pct(info.poolFrac)})` : 'dug out: no rubble left';
      tip.innerHTML = '';
      tip.append(el('div', undefined, `${blockLabel(session.state, idxOf(session.state, info.x, info.y), debugView.coords)} · Held · ${slot}`), el('div', info.poolLeft > 0 ? 'muted' : 'bad', `${info.district} · ${rubble}`));
      tip.hidden = false;
      const w0 = tip.offsetWidth, h0 = tip.offsetHeight;
      tip.style.left = `${Math.min(px + 14, window.innerWidth - w0 - 8)}px`; tip.style.top = `${Math.min(py + 14, window.innerHeight - h0 - 8)}px`;
      return;
    }
    // RI-03 (plan §4.1): the map previews; the third line is the installation's answer — ready, or the prerequisite
    // the physical Activate still lacks (adjacency, the substation, the pole run, the supply, the materials, reach)
    const sign = info.frontDelta >= 0 ? '+' : '−';
    const line1 = `${blockLabel(session.state, idxOf(session.state, info.x, info.y), debugView.coords)} — rot ${pct(info.rot)} · front ${sign}${Math.abs(info.frontDelta)} · closes ${info.closes}`;
    const cost = info.cost ? ` · claim ${info.cost.steel} steel + ${info.cost.copper} Cu at its substation` : '';
    const line2 = `${info.district}${info.well ? ' · well' : ''}${cost} · wake bloom ≈ ${info.wakeBloomCrawlers} crawlers`;
    const chk = activationCheck(session.state, info.x, info.y);
    tip.innerHTML = '';
    tip.append(el('div', undefined, line1), el('div', 'muted', line2), el('div', chk.ok ? 'muted' : 'bad', chk.ok ? 'ready — E at its substation activates the claim' : `on foot: ${chk.reason}`));
    tip.hidden = false;
    const w = tip.offsetWidth, hgt = tip.offsetHeight;
    tip.style.left = `${Math.max(12, Math.min(px + 14, window.innerWidth - w - 12))}px`;
    tip.style.top = `${Math.min(py + 14, window.innerHeight - hgt - 8)}px`;
  }

  const shell = createUiShell(root, {releaseInput: hooks.releaseInput, cancelSelection: hooks.cancelSelection, speed:()=>session.state.speed, setSpeed:speed=>setSpeed(session,speed)});
  const journal=root.querySelector<HTMLElement>('.campaign-guide:not(.item-guide)');
  const recipes=root.querySelector<HTMLElement>('.item-guide');
  const copyPanel=root.querySelector<HTMLElement>('[aria-label="Blueprint clipboard"]');
  const libraryPanel=root.querySelector<HTMLElement>('[aria-label="Blueprint library and orders"]');
  const truckPanel=root.querySelector<HTMLElement>('[aria-label="Truck construction"]');
  if(campaign)buildUi=createBuildPanel(session,buildSec,shell,tool=>panelRef.onPick?.(tool),hooks.selectedTool,hooks.rotateTool,hooks.cancelTool,historyRow,copyPanel,libraryPanel);
  shell.register('build','Build',[buildSec,...(!campaign?[copyPanel,libraryPanel].filter(Boolean) as HTMLElement[]:[])],()=>{buildSec.hidden=false;});
  shell.register('inventory','Inventory',[pocketSec],()=>{pocketSec.hidden=false;});
  shell.register('inspection','Inspection',[routingSec],()=>{routingSec.hidden=false;},()=>{if(!inspectionView.pinned){inspectionView.machineId=null;inspectionId=null;}routingSec.hidden=true;});
  if(campaign){
    inspectionUi=createInspectionPanel(session,routingSec,shell,[recipeLabel,routingHead,filterLabel,priorityLabel],{locate:hooks.locate,item:item=>{shell.open('help');guide?.openItem(item);},inventory:(x,y)=>panelRef.openPocketsAt(x,y),route:(x,y)=>panelRef.openStationRoute(x,y)});
    inventoryUi=createInventoryPanel(session,pocketSec,()=>pocketId,freightForm);
  }
  shell.register('truck','Truck cargo',[truckSec]);
  shell.register('route','Station route',[routeSec]);
  if(guide&&journal) shell.register('projects','Projects',[journal],()=>guide.openDiscoveries());
  shell.register('help','Help',[controlsHelp(),...[recipes].filter(Boolean) as HTMLElement[]],()=>guide?.openItem());
  // Keep stock, loss history, exact power/buffers and legacy management out of Developer.
  debug.hidden=false;
  const management=[hudSec,itemStats,lineSec,...(defenceSection?[defenceSection]:[]),...(!campaign?[stockSec,ringSec,facSec,sumSec]:[])];
  shell.register('management','Management',management);
  if(campaign){const truckAccess=el('button',undefined,'Truck cargo');truckAccess.onclick=openTruck;hudSec.append(truckAccess);}
  if(campaign&&truckPanel){shell.register('construction','Construction delivery',[truckPanel]);const delivery=el('button',undefined,'Construction delivery');delivery.onclick=()=>shell.open('construction');truckSec.append(delivery);const manage=el('button',undefined,'Construction delivery');manage.onclick=()=>shell.open('construction');hudSec.append(manage);}
  shell.register('developer','Developer',[header,...(campaign?[sumSec]:[])]);
  debug.remove();
  shell.action(`Build (${shortcut('build')})`,()=>panelRef.toggleBuild());
  shell.action(`Inventory (${shortcut('pockets')})`,()=>panelRef.togglePockets());
  shell.action(`Map (${shortcut('map')})`,()=>hooks.onToggleView());
  if(guide)shell.drawerButton('projects',`Projects (${shortcut('projects')})`);
  shell.drawerButton('management','Management');
  if(campaign)shell.drawerButton('construction','Construction');
  shell.drawerButton('help','Help');
  shell.action('Pause menu',()=>shell.pause());
  shell.pauseAction(`Save (Ctrl+${shortcut('save')})`,saveGame);
  shell.pauseAction(`Load (Ctrl+${shortcut('load')})`,loadGame);
  shell.pauseAction('Download save',()=>btnState.click());
  shell.pauseAction('Copy seed/settings link',()=>btnLink.click());
  shell.pauseAction('Controls and item help',()=>shell.pauseChild('help'));
  shell.pauseAction('Developer',()=>shell.pauseChild('developer'));
  const startScreen=el('section'),seedInput=el('input'),seedLabel=el('label',undefined,'City seed');
  seedInput.type='number';seedInput.min='1';seedInput.max='2147483647';seedInput.step='1';seedInput.value=String(st.seed);seedInput.required=true;seedLabel.append(seedInput);
  const startButton=el('button','primary','Start city');startButton.onclick=()=>{if(!seedInput.reportValidity())return;if(window.confirm('Start a new city? Unsaved progress will be lost.'))location.href=shareUrl({...session.params,seed:Number(seedInput.value),state:null,autoplay:null});};
  startScreen.append(el('p',undefined,'Choose a seed for a fresh city. Save your current game before starting again.'),seedLabel,startButton);
  shell.register('start','Start a city',[startScreen]);shell.pauseAction('Start a new city',()=>shell.pauseChild('start'));
  const panelRef: Panel = {
    shell,
    openStationRoute(x,y){const m=machineAt(session.state,x,y);if(m?.kind!=='tramstop')return;shell.open('route');transportView.stopId=m.id;lastUpdate=-1e9;update(performance.now());routeSec.scrollIntoView({block:'nearest'});},
    openTruck,openRoutingAt:openInspection,openInspectionAt:openInspection,
    update, tooltip, tooltipText, toast, setView, onPick: null, onBlueprint: null, onRemovalPreview:null,
    toggleDebug() { debugView.coords = !debugView.coords; shell.toggle('developer'); ringKey = ''; lastFacKey = ''; return debugView.coords; },
    togglePockets() { pocketAt=null;pocketId=null; const open=shell.active()!=='inventory'; if(open)shell.open('inventory');else shell.close(); lastUpdate=-1e9;update(performance.now()); return open; },
    openPocketsAt(x, y) {   // RI-05
      const stop=machineAt(session.state,x,y);pocketId=stop&&['chest','tramstop'].includes(stop.kind)?stop.id:null;transportView.stopId=stop?.kind==='tramstop'?stop.id:null;
      const same = pocketAt !== null && pocketAt[0] === x && pocketAt[1] === y;
      if (same && shell.active()==='inventory') { shell.close(); pocketSec.hidden = true; pocketAt = null; } else { shell.open('inventory'); pocketAt = pocketId===null?null:[x,y]; pocketSec.hidden = false; }
      lastUpdate = -1e9;update(performance.now());
      if (!pocketSec.hidden) pocketSec.scrollIntoView({ block: 'nearest' });
    },
    toggleBuild() { shell.toggle('build'); return shell.active()==='build'; },
    closeAll() { shell.close(); if(!inspectionView.pinned)inspectionView.machineId=null; transportView.stopId=null; routeSec.hidden=true; },
    setSelectedEdge(e) {
      selected = e ? e.id : null; ringKey = '';
      if (e) toast(`${edgeName(session.state, e.id)}${debugView.coords ? ` (${e.from.x},${e.from.y}) → (${e.to.x},${e.to.y})` : ''} is ring position ${e.ringPos + 1} of ${session.state.ring.length}; hopper ${pct(e.level)}`);
    },
  };
  return panelRef;
}
