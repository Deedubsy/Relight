import { bound, BINDINGS, shortcut } from './controls';
import { hudInset } from './view';

/** DOM presentation only. Domain panels keep their queries and command handlers. */
export function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}
export const uiInput = { blocked: false, modal: false };
export function uiPalette() {
  const css = getComputedStyle(document.documentElement);
  return { color: css.getPropertyValue('--ui-secondary').trim(), backgroundColor: css.getPropertyValue('--ui-bg').trim(), fontFamily: css.fontFamily, fontSize: '16px' };
}
type Adapter = { body: HTMLElement; title: string; enter?: () => void; leave?: () => void };
export interface ShellHooks { releaseInput(): void; cancelSelection(): boolean; speed(): number; setSpeed(speed: number): void }

export function createUiShell(root: HTMLElement, hooks: ShellHooks) {
  document.body.classList.add('ui-shell');
  root.setAttribute('aria-label', 'Game panels');
  const nav = el('nav', 'ui-navigation'); nav.setAttribute('aria-label', 'Game controls');
  const brand = el('span', 'ui-brand', 'RELIGHT'); nav.append(brand);
  const drawer = el('section', 'ui-drawer'); drawer.hidden = true;
  const heading = el('header', 'ui-drawer-heading'), title = el('h2'); title.id = 'ui-drawer-title';
  const close = el('button', undefined, 'Close'); close.setAttribute('aria-label', 'Close panel');
  heading.append(title, close); drawer.append(heading); drawer.setAttribute('aria-labelledby', title.id);
  const modal = el('section', 'ui-modal'); modal.hidden = true; modal.tabIndex = -1;
  modal.setAttribute('role', 'dialog'); modal.setAttribute('aria-modal', 'true'); modal.setAttribute('aria-labelledby', 'pause-title');
  const pauseTitle = el('h1', undefined, 'Paused'); pauseTitle.id = 'pause-title';
  const pauseActions = el('div', 'ui-pause-actions'), child = el('div', 'ui-modal-child'); child.hidden = true;
  const resume = el('button', 'primary', 'Resume'); pauseActions.append(resume); modal.append(pauseTitle, pauseActions, child);
  root.append(drawer, modal); document.getElementById('app')!.append(nav);
  const adapters = new Map<string, Adapter>();
  let active: string | null = null, childId: string | null = null, previousSpeed = 1;
  let returnFocus: HTMLElement | null = null, pauseFocus: HTMLElement | null = null;
  const held = new Set<string>(), suppressed = new Set<string>();
  const canvas = () => document.querySelector<HTMLCanvasElement>('#map > canvas');
  const inUi = (target: EventTarget | null) => target instanceof Element && !!target.closest('#panel, .ui-navigation, #threat-controls, .ui-hud');
  function release() { for (const key of held) suppressed.add(key); hooks.releaseInput(); document.getElementById('tooltip')!.hidden = true; }
  function sync() {
    uiInput.modal = !modal.hidden; uiInput.blocked = !modal.hidden || active !== null || inUi(document.activeElement);
    hudInset.right = active && modal.hidden ? drawer.getBoundingClientRect().width + 24 : 0;
    hudInset.bottom = nav.offsetHeight + 24;
    document.documentElement.style.setProperty('--ui-nav-height', nav.offsetHeight+'px');
    document.documentElement.style.setProperty('--ui-drawer-inset',hudInset.right+'px');
    nav.querySelectorAll<HTMLButtonElement>('[data-drawer]').forEach(b => b.setAttribute('aria-expanded', String(b.dataset.drawer === active)));
  }
  function restore(target: HTMLElement | null) {
    const valid = target?.isConnected && target.getClientRects().length && !target.closest('[hidden]');
    (valid ? target : canvas())?.focus({ preventScroll: true }); sync();
  }
  function closeMenus(){nav.querySelectorAll<HTMLDetailsElement>('details[open]').forEach(d=>{d.open=false;});}
  function closeDrawer(focus = true) {
    closeMenus();
    if (!active) return;
    const adapter = adapters.get(active)!; adapter.body.hidden = true; adapter.leave?.(); active = null; drawer.hidden = true;
    release(); if (focus) restore(returnFocus); sync();
  }
  function open(id: string) {
    const adapter = adapters.get(id); if (!adapter || !modal.hidden) return;
    if (active !== id) {
      const focus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      closeDrawer(false); returnFocus = focus; active = id;
      adapter.body.hidden = false; drawer.hidden = false; title.textContent = adapter.title;
    }
    release(); adapter.enter?.(); close.focus({ preventScroll: true }); sync();
  }
  function closeChild() {
    if (!childId) return;
    const adapter = adapters.get(childId)!; adapter.body.hidden = true; drawer.append(adapter.body); adapter.leave?.();
    childId = null; child.replaceChildren(); child.hidden = true; pauseActions.hidden = false; resume.focus(); sync();
  }
  function pause() {
    if (!modal.hidden) return;
    pauseFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (hooks.speed() > 0) previousSpeed = hooks.speed();
    release(); closeDrawer(false); hooks.setSpeed(0); modal.hidden = false; nav.inert = true;
    resume.focus({ preventScroll: true }); sync();
  }
  function unpause() {
    closeChild(); modal.hidden = true; nav.inert = false; release(); hooks.setSpeed(previousSpeed); restore(pauseFocus); sync();
  }
  function pauseChild(id: string) {
    const adapter = adapters.get(id); if (!adapter) return;
    closeChild(); childId = id; pauseActions.hidden = true; child.hidden = false;
    const back = el('button', undefined, 'Back to Pause'); back.onclick = closeChild;
    child.append(back, el('h2', undefined, adapter.title), adapter.body); adapter.body.hidden = false; adapter.enter?.(); back.focus(); sync();
  }
  function action(label: string, run: () => void, destination: HTMLElement = nav) {
    const b = el('button', undefined, label); b.type = 'button'; b.onclick = run; destination.append(b); return b;
  }
  function register(id: string, label: string, nodes: HTMLElement[], enter?: () => void, leave?: () => void) {
    if (adapters.has(id)) throw Error(`Duplicate UI adapter: ${id}`);
    const body = el('div', 'ui-drawer-body'); body.dataset.adapter = id; body.hidden = true; body.append(...nodes); drawer.append(body);
    adapters.set(id, { body, title: label, enter, leave });
  }
  function toggle(id: string) { if (active === id) closeDrawer(); else open(id); }
  function drawerButton(id: string, label: string) { const b = action(label, () => toggle(id)); b.dataset.drawer = id; b.setAttribute('aria-expanded', 'false'); return b; }
  close.onclick = () => closeDrawer(); resume.onclick = unpause;
  // Capture before Phaser's window handlers; native form editing remains local to the UI.
  window.addEventListener('keydown', event => {
    const key = event.code || event.key; if(!event.repeat)suppressed.delete(key); held.add(key);
    if (suppressed.has(key)) { event.stopImmediatePropagation(); if (!inUi(event.target)) event.preventDefault(); return; }
    if (bound('cancel', event.key)) {
      event.preventDefault(); event.stopImmediatePropagation(); if (event.repeat) return;
      const menu=nav.querySelector<HTMLDetailsElement>('details[open]');if(menu){menu.open=false;menu.querySelector('summary')?.focus();return;}
      if (childId) closeChild(); else if (!modal.hidden) unpause(); else if (active) closeDrawer(); else if (!hooks.cancelSelection()) pause();
      return;
    }
    if (!modal.hidden && event.key === 'Tab') {
      const nodes = Array.from(modal.querySelectorAll<HTMLElement>('button:not(:disabled), a[href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]')).filter(n => n.getClientRects().length > 0 && !n.closest('[hidden]'));
      const index = nodes.indexOf(document.activeElement as HTMLElement), next = (index + (event.shiftKey ? -1 : 1) + nodes.length) % nodes.length;
      event.preventDefault(); event.stopImmediatePropagation(); (nodes[next] ?? modal).focus(); return;
    }
    const textFocus = event.target instanceof Element && !!event.target.closest('input, textarea, select, [contenteditable=true]');
    if(!textFocus && (event.ctrlKey||event.metaKey) && (bound('save',event.key)||bound('load',event.key)))return;
    if (!modal.hidden || active || inUi(event.target)) { event.stopPropagation(); }
  }, true);
  window.addEventListener('keyup', event => { held.delete(event.code || event.key); suppressed.delete(event.code || event.key); }, true);
  window.addEventListener('pointerdown', event => {
    if (inUi(event.target)) { release(); return; }
    if (!modal.hidden || active) { event.preventDefault(); event.stopImmediatePropagation(); if (modal.hidden) closeDrawer(); return; }
    if(event.target === canvas()){canvas()?.focus({preventScroll:true});sync();}
  }, true);
  window.addEventListener('pointerup', event => { if (inUi(event.target) || event.target !== canvas()) release(); }, true);
  window.addEventListener('focusin', event => { if (inUi(event.target)) release(); if (!modal.hidden && !modal.contains(event.target as Node)) resume.focus(); sync(); });
  window.addEventListener('blur', () => { release(); held.clear(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) { release(); held.clear(); } });
  function protect(surface:HTMLElement){for (const name of ['pointerdown', 'pointerup', 'click', 'contextmenu', 'wheel']) surface.addEventListener(name,event=>event.stopPropagation());}
  for (const surface of [root, nav, document.getElementById('threat-controls')].filter(Boolean) as HTMLElement[]) {
    for (const name of ['pointerdown', 'pointerup', 'click', 'contextmenu', 'wheel']) surface.addEventListener(name, event => event.stopPropagation());
  }
  new ResizeObserver(sync).observe(nav); new ResizeObserver(sync).observe(drawer);
  return { register, open, toggle, close: closeDrawer, action, drawerButton, pause, pauseChild,
    pauseAction: (label: string, run: () => void) => action(label, run, pauseActions),
    active: () => active, paused: () => !modal.hidden, sync, protect,
  };
}
export type UiShell = ReturnType<typeof createUiShell>;

export function controlsHelp() {
  const body = el('section'); body.append(el('h2', undefined, 'Controls'), el('p', 'hint', 'Click the city to return to world controls. Escape closes one layer, cancels placement, then opens Pause.'));
  const list = el('dl', 'ui-controls');
  for (const [name, keys] of Object.entries(BINDINGS)) if (keys.length) {
    const modifier = ['copy', 'paste', 'save', 'load', 'undo', 'redo'].includes(name) ? 'Ctrl / Cmd + ' : '';
    list.append(el('dt', undefined, name), el('dd', undefined, keys.some(k=>/^[0-9]$/.test(k))?'Quickbar slot (see current assignments)':modifier + keys.map(k => k === ' ' ? 'Space' : k).join(' / ')));
  }
  body.append(list, el('p', 'hint', `Projects: ${shortcut('projects')}. H / V mirror while pasting a blueprint; plain C / H / V select chest / stop / tram in world mode. Binding and scaling editors arrive with Settings.`)); return body;
}
