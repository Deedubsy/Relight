import {CAMPAIGN_KINDS,type Kind} from '@relight/sim';
export type QuickTool=Exclude<Kind,'depot'>|'rifle';
export const DEFAULT_QUICKBAR:readonly (QuickTool|null)[]=['belt','inserter','excavator','assembler','turret','lamp','pole','generator','rifle','floodlight'];
export const QUICKBAR_KEYS=['1','2','3','4','5','6','7','8','9','0'] as const;
export interface UiPreferences {version:1;quickbar:(QuickTool|null)[]}
export function parseUiPreferences(raw:string|null):UiPreferences {
  const fallback=():UiPreferences=>({version:1,quickbar:[...DEFAULT_QUICKBAR]});
  try{const v=JSON.parse(raw??'null');if(v?.version!==1||!Array.isArray(v.quickbar)||v.quickbar.length!==10||v.quickbar.some((k:unknown)=>k!==null&&k!=='rifle'&&(!CAMPAIGN_KINDS.includes(k as Kind)||k==='depot')))return fallback();return {version:1,quickbar:[...v.quickbar]};}catch{return fallback();}
}
export function readUiPreferences():UiPreferences {try{return parseUiPreferences(localStorage.getItem('relight.ui.v1'));}catch{return parseUiPreferences(null);}}
export function saveQuickbar(slots:readonly (QuickTool|null)[]):boolean {try{let old:UiPreferences|null=null;try{old=JSON.parse(localStorage.getItem('relight.ui.v1')??'null');}catch{/* Replace corrupt preferences on the next explicit edit. */}localStorage.setItem('relight.ui.v1',JSON.stringify({...((old?.version===1)?old:{}),version:1,quickbar:slots}));return true;}catch{return false;}}
/** Assignment swaps an already-used tool, preserving ten stable positions and unrelated choices. */
export function assignQuickbar(slots:readonly (QuickTool|null)[],index:number,tool:QuickTool|null):(QuickTool|null)[]{
  const next=[...slots];if(!Number.isInteger(index)||index<0||index>=10)return next;
  const prior=tool===null?-1:next.indexOf(tool);if(prior>=0&&prior!==index)next[prior]=next[index];next[index]=tool;return next;
}
export const quickbarView:{slots:(QuickTool|null)[]}={slots:[...DEFAULT_QUICKBAR]};
