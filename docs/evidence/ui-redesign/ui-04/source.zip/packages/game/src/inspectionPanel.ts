import {inspectMachine,machineById,knownInputSource,ITEMS,type Item} from '@relight/sim';
import {el,type UiShell} from './uiShell';
import {dispatch,type Session} from './session';
import {inspectionView} from './view';
/** Stable identity, controls and details state; only the read-only facts change between ticks. */
export function createInspectionPanel(session:Session,root:HTMLElement,shell:UiShell,controls:HTMLElement[],hooks:{locate(x:number,y:number):void;item(item:Item):void;inventory(x:number,y:number):void;route(x:number,y:number):void}){
 const dismiss=el('button',undefined,'Dismiss removed inspection'),title=el('h2'),location=el('p','hint'),status=el('p','inspection-status'),output=el('section'),inputs=el('section'),blockers=el('section','inspection-blockers'),actions=el('section'),details=el('details','inspection-details'),facts=el('div'),result=el('p','action-result');
 const pin=el('button',undefined,'Pin inspection'),locate=el('button',undefined,'Locate machine'),transfer=el('button',undefined,'Open supplies'),route=el('button',undefined,'Station route'),feed=el('button',undefined,'Load carried magazines'),chip=el('button','ui-hud inspection-chip');chip.hidden=true;document.getElementById('app')!.append(chip);shell.protect(chip);
 actions.append(el('h3',undefined,'Actions'),pin,locate,transfer,route,feed,...controls,result);details.append(el('summary',undefined,'Details: rates, circuit and contents'),facts);root.replaceChildren(title,location,status,output,inputs,blockers,actions,details,dismiss);dismiss.onclick=()=>{inspectionView.pinned=false;shell.close();};
 const machine=()=>inspectionView.machineId===null?null:machineById(session.state,inspectionView.machineId);
 pin.onclick=()=>{inspectionView.pinned=!inspectionView.pinned;};chip.onclick=()=>{shell.open('inspection');root.hidden=false;};
 locate.onclick=()=>{const m=machine();if(m)hooks.locate(m.x+m.size/2,m.y+m.size/2);};
 transfer.onclick=()=>{const m=machine();if(m)hooks.inventory(m.x,m.y);};route.onclick=()=>{const m=machine();if(m)hooks.route(m.x,m.y);};
 feed.onclick=()=>{const m=machine();if(m){const r=dispatch(session,{type:'factory',action:{type:'feed',x:m.x,y:m.y}});result.textContent=r.reason;}};
 let key='',constraintsKey='',lastId:number|null=null;
 const p=(text:string)=>el('p',undefined,text),num=(n:number|null)=>n===null?'—':Number(n.toFixed(2)).toLocaleString();
 return {update(){
  const id=inspectionView.machineId,info=id===null?null:inspectMachine(session.state,id),m=machine();
  chip.hidden=!inspectionView.pinned||id===null||shell.active()==='inspection'||shell.paused();chip.textContent=info?`Inspect ${info.title} · ${info.status.state}`:'Machine removed · inspection';
  if(!chip.hidden){const clock=document.querySelector('.hud-time')?.getBoundingClientRect(),map=document.querySelector('.hud-minimap')?.getBoundingClientRect();chip.style.top=`${Math.max(clock?.bottom??0,map&&map.top<100?map.bottom:0)+12}px`;}
  if(lastId!==id){lastId=id;details.open=false;result.textContent='';key='';constraintsKey='';}
  pin.textContent=inspectionView.pinned?'Unpin inspection':'Pin inspection';pin.setAttribute('aria-pressed',String(inspectionView.pinned));
  dismiss.hidden=!!info||!inspectionView.pinned;
  if(!info){title.textContent='Machine removed';status.textContent='The selected machine no longer exists.';location.textContent='Select another machine to inspect it.';for(const n of [output,inputs,blockers,actions,details])n.hidden=true;return;}
  for(const n of [output,inputs,blockers,actions,details])n.hidden=false;
  title.textContent=info.title;location.textContent=info.location;status.textContent=`${info.status.state==='running'?'Running':info.status.state==='idle'?'Idle':info.status.state==='off'?'Offline':info.status.state==='blocked'?'Blocked':'Waiting'} · ${info.status.reason}`;status.dataset.state=info.status.state;
  transfer.hidden=!['chest','tramstop','depot'].includes(info.kind);route.hidden=info.kind!=='tramstop';feed.hidden=!['turret','generator'].includes(info.kind);feed.textContent=info.kind==='generator'?'Load carried coal':'Load carried magazines';feed.disabled=!info.reachable;
  const nextKey=JSON.stringify(info);if(nextKey===key)return;key=nextKey;
  const measured=info.measured;output.replaceChildren(el('h3',undefined,'Useful output'));
  if(measured){output.append(p(measured.seconds>0?`${info.measurement} over ${num(measured.seconds)} simulation seconds.`:'Waiting for simulation time — no measured output yet.'));for(const r of measured.rows)if(r.produced>0||info.nominal.some(n=>n.item===r.item&&n.output>0))output.append(p(`${r.item}: ${num(r.producedPerMin)}/min measured · ${num(r.produced)} recorded`));}else output.append(p(info.capacity??info.status.reason));
  inputs.replaceChildren(el('h3',undefined,'Inputs'));
  if(info.recipe)inputs.append(p(`Recipe: ${info.recipe}`));
  for(const r of info.nominal.filter(n=>n.input>0))inputs.append(p(`${r.item}: ${num(m?.inv[r.item]??0)} buffered · ${num(r.input)}/min nominal input`));
  if(!info.nominal.some(n=>n.input>0))inputs.append(p(info.kind==='generator'?`${num(m?.inv.coal??0)} coal in fuel store`:info.kind==='turret'?`${num(m?.inv.rounds??0)} rounds in hopper`:'No recipe inputs.'));
  const ck=JSON.stringify([info.blockers,info.nextInputs,info.status.state,info.reachable,...[...info.blockers,...info.nextInputs].filter(b=>b.item).map(b=>knownInputSource(session.state,b.item!))]);
  if(ck!==constraintsKey){constraintsKey=ck;
  blockers.replaceChildren(el('h3',undefined,'Current constraints'));
  if(!info.blockers.length)blockers.append(p(info.status.state==='running'?'No current blocker.':info.status.reason));
  for(const b of [...info.blockers,...info.nextInputs]){const row=el('div','inspection-constraint');row.append(p(b.text));if(b.item){const item=b.item,help=el('button',undefined,`About ${item}`);help.onclick=()=>hooks.item(item);row.append(help);const source=knownInputSource(session.state,item);if(source){const go=el('button',undefined,`Locate ${source.label}`);go.onclick=()=>hooks.locate(source.x,source.y);row.append(go);}}blockers.append(row);}
  if(!info.reachable)blockers.append(p('Out of reach — walk closer to change settings or transfer.'));
  }
  const c=info.circuit;facts.replaceChildren(p(`${c.scope}: ${num(c.supply)} kW supply / ${num(c.demand)} kW demand / ${num(c.load)} kW load / ${num(c.throttle*100)}% throttle`),p(`Machine draw: ${info.draw} kW`));
  for(const r of info.nominal)facts.append(p(`${r.item}: nominal ${num(r.input)} in / ${num(r.output)} out per min; power-limited capacity ${num(r.input*info.scale)} in / ${num(r.output*info.scale)} out per min`));
  if(info.capacity)facts.append(p(info.capacity));facts.append(el('h3',undefined,'Separate stores'));
  if(!info.contents.length)facts.append(p('Contents: empty'));for(const c of info.contents)facts.append(p(`${c.place} · ${c.item}: ${num(c.count)}`));for(const setting of info.settings)facts.append(p(setting));if(info.range)facts.append(p(info.range));
 }};
}
