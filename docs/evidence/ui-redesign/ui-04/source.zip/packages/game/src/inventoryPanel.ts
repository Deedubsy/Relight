import {ITEMS,KIND_LABEL,knownEquipment,chestTransferPreview,chestCount,machineById,invStacks,INV_STACKS,stackSize,STOP_CAP,SUPPLY_CHEST_CAP,freightInbound,handCraftCheck,type ChestItem,type Kind} from '@relight/sim';
import {el} from './uiShell';
import {dispatch,type Session} from './session';
/** One transfer drawer, with separately named stores and authoritative partial-transfer previews. */
export function createInventoryPanel(session:Session,root:HTMLElement,target:()=>number|null,freight:HTMLElement){
 const title=el('h2'),pockets=el('p'),store=el('p'),notice=el('p','action-result'),list=el('div','transfer-list'),craft=el('button',undefined,'Craft 1 magazine'),craftReason=el('p','hint');
 root.replaceChildren(title,pockets,store,notice,list,craft,craftReason,freight);let key='',lastTarget:number|null|undefined;
 const rows=new Map<ChestItem,{root:HTMLElement;counts:HTMLElement;take:HTMLButtonElement;put:HTMLButtonElement;reason:HTMLElement}>();
 const send=(item:ChestItem,put:boolean,n:number)=>{const id=target(),m=id===null?null:machineById(session.state,id);if(id!==null&&!m){notice.textContent='Selected store removed. Select a store again.';return;}const r=dispatch(session,{type:'factory',action:{type:put?'chestPut':'chestTake',item,n,...(m?{x:m.x,y:m.y}:{})}});notice.textContent=r.reason;};
 craft.onclick=()=>{notice.textContent=dispatch(session,{type:'factory',action:{type:'craft',item:'magazine',count:1}}).reason;};
 return {update(){
  const st=session.state,id=target(),m=id===null?null:machineById(st,id),removed=id!==null&&!m;
  if(lastTarget!==id){lastTarget=id;notice.textContent='';}
  title.textContent=removed?'Selected store removed':m?.kind==='tramstop'?'Station transfers':m?'Supply chest transfers':'Home supplies';
  pockets.textContent=`Pockets · ${invStacks(st.engineer.inv)} / ${INV_STACKS} stacks`;store.textContent=removed?'Transfers are closed. Select another store.':m?m.kind==='tramstop'?`Platform ${Object.values(m.inv).reduce((a,b)=>a+b,0)}/${STOP_CAP} · Arrivals ${Object.values(m.cargo??{}).reduce((a,b)=>a+b,0)}/${STOP_CAP} · ${freightInbound(st,m.id)} reserved inbound. Take uses arrivals first, then platform. Put uses platform.`:`Chest ${Object.values(m.inv).reduce((a,b)=>a+b,0)}/${SUPPLY_CHEST_CAP} items`:'Home stock stays here until you take it into your pockets.';
  const items=[...new Set<ChestItem>([...ITEMS,...Object.keys(st.engineer.inv).filter(k=>k in KIND_LABEL&&k!=='depot') as ChestItem[],...Object.keys(m?.inv??{}).filter(k=>k in KIND_LABEL&&k!=='depot') as ChestItem[]])].filter(k=>!(k in KIND_LABEL)||knownEquipment(st,k as Kind));
  if(key!==items.join('|')){key=items.join('|');list.replaceChildren();for(const item of items){let r=rows.get(item);if(!r){const article=el('article','transfer-card'),counts=el('p'),take=el('button',undefined,`Take ${item==='magazine'?5:stackSize(item)}`),put=el('button',undefined,'Put all'),reason=el('p','hint');article.append(el('h3',undefined,item),counts,take,put,reason);take.onclick=()=>send(item,false,item==='magazine'?5:stackSize(item));put.onclick=()=>send(item,true,1e9);r={root:article,counts,take,put,reason};rows.set(item,r);}list.append(r.root);}}
  for(const item of items){const r=rows.get(item)!,at=m?[m.x,m.y] as [number,number]:undefined,take=removed?{moved:0,reason:'Store removed'}:chestTransferPreview(st,item,item==='magazine'?5:stackSize(item),false,at),put=removed?{moved:0,reason:'Store removed'}:chestTransferPreview(st,item,1e9,true,at);
   r.counts.textContent=`Pockets ${st.engineer.inv[item]??0} · ${removed?'Store removed':m?.kind==='tramstop'?`Platform ${m.inv[item]??0} · Arrivals ${m.cargo?.[item]??0}`:m?`Chest ${m.inv[item]??0}`:`Home ${chestCount(st,item)}`}`;
   r.take.disabled=r.put.disabled=removed;r.take.setAttribute('aria-disabled',String(!take.moved));r.put.setAttribute('aria-disabled',String(!put.moved));r.reason.textContent=`Take: ${take.moved?`${take.moved} available`:take.reason} · Put: ${put.moved?`${put.moved} available`:put.reason}`;
  }
  const check=handCraftCheck(st);craft.disabled=!!check.reason;craftReason.textContent=check.reason||'Uses carried steel and copper at the Home workbench.';
 }};
}
