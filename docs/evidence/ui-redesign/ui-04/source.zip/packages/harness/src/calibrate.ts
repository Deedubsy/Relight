/** Calibration harness (constitution Phase 2, rule 5). Runs the proto's config with the three bots on the scattered
 *  map, seeds 3/4/5, economy on, 3 h sim, and scores the constitution's seven targets C1–C7 from the sim's own state.
 *  Reported in PHASE_2_REPORT.md; the JSON goes to docs/experiments/calibration.json.
 *
 *    npm run calibrate -- '{"startAsmRate":10,"eco":{"yieldPerMin":4}}' [--hours 3] [--seeds 3,4,5]
 *                        [--bots compact,spike,cheapest] [--economy 0] [--build 0] [--react 1] [--map river|lattice] [--walk 0] [--out file.json] [--md file.md]
 *
 *  --build 0  the bots never build an assembler (a tester who ignores the HUD).
 *  --react 1  harness-only stand-in for a tester who builds when a pip first leaves green: implies --build 0; adds an
 *             assembler when the worst pip is amber or red, the stock affords it, and none was added in the last 10 min.
 *
 *  Overrides are applied on top of protoCalibrated(DEFAULT_CONFIG) so a lever can be tried without editing types.ts.
 *
 *  C1 and C2 are scored from minute 1 (D-P2-1, Gate A 2026-09-03): 200 start rounds fill two of the HQ's three hoppers,
 *  so the third pip shows amber then red for the first 30 s; that flicker teaches the pip ladder and is not a miss.
 *  The `amber`/`red` columns still report the first non-green tick from t = 0 for the record.
 *
 *  D-R2 (2026-09-04): with the bots walking (D5), a claim's kit walks out from the chest, so every new edge is red
 *  until the engineer arrives; that red is the walking cost, not a miss. C1 and C2 are therefore scored on *kitted*
 *  edges only (`e.kit !== false`): C1 "first enclosure before first amber on a kitted edge", C2 "no red on a kitted
 *  edge before 120 min". The all-edge columns stay in the table for the record. */
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { configOf, stamp, stampLine } from './provenance';
import {
  configHash, generateMap, citySpec, CityPreset, CITY_PRESETS, createState, step, takeEvents,
  createBot, botCommands, Command, Policy, heldCount, frontage, interior, ammoStatus, pipOf, slotInfo, asmCount,
} from '@relight/sim';

const argv = process.argv.slice(2);
const flag = (name: string, dflt: string): string => { const i = argv.indexOf(name); return i >= 0 && i + 1 < argv.length ? argv[i + 1] : dflt; };
const overridesArg = argv.find(a => a.startsWith('{')) ?? '{}';
const HOURS = Number(flag('--hours', '3'));
const SEEDS = flag('--seeds', '3,4,5').split(',').map(Number);
const BOTS = flag('--bots', 'compact,spike,cheapest').split(',') as Policy[];
const ECONOMY = flag('--economy', '1') !== '0';
const REACT = flag('--react', '0') !== '0';
const BUILD = !REACT && flag('--build', '1') !== '0';
// Rework Step 5 (D5/D6): calibration runs on the street-first city with walking bots unless told otherwise
const MAP = flag('--map', 'river') as 'lattice' | CityPreset;
if (MAP !== 'lattice' && !(CITY_PRESETS as readonly string[]).includes(MAP)) throw new Error(`--map: lattice or one of ${CITY_PRESETS.join(', ')}`);
const WALK = MAP !== 'lattice' && flag('--walk', '1') !== '0';
// paths are taken relative to where npm was invoked (INIT_CWD), so `npm run calibrate -- --out docs/x.json` works from the root
const CWD = process.env.INIT_CWD ?? process.cwd();
const OUT = flag('--out', '') && resolve(CWD, flag('--out', ''));

const CONFIG_REF = { kind: 'calibration' as const, map: MAP, walk: WALK, economy: ECONOMY, overrides: JSON.parse(overridesArg) as Record<string, unknown> };
const config = configOf(CONFIG_REF);   // protoCalibrated(DEFAULT_CONFIG + scatter/economy/walk) deep-merged with --overrides (provenance.ts)
const HASH = configHash(config);
const PROV = stamp(CONFIG_REF);         // rule 11: commit + config hash in every generated file

interface Run {
  bot: Policy; seed: number;
  firstAmber: number | null; firstRed: number | null; firstAmberAfter1: number | null; firstRedAfter1: number | null;
  /** D-R2: first amber / red on a kitted edge, from minute 1 (the C1/C2 numbers). */
  firstAmberKitted: number | null; firstRedKitted: number | null;
  firstLoss: number | null; firstEnclosure: number | null;
  lost: number; stalls: number; firstStall: number | null; claims: number;
  held: Record<number, number>; front180: number; interior180: number;
  copper180: number; steel180: number; minSteel: number; minSteelAt: number; patchOutAt: number | null;
  assemblers: number[]; production180: number; peakDemand: number; peakDemandAt: number;
  mags: number; magsMade: number; magsPerHeld: number; amberTicks: number; redTicks: number;
  slots: Record<number, { used: number; free: number; dry: number }>;   // at 60/120/180 min
  maxAsmBefore120: number; machinesLost: number; distinctLost: number; dryLog: { t: number; x: number; y: number; district: string }[];
}

function run(bot: Policy, seed: number): Run {
  const spec = MAP === 'lattice' ? generateMap(seed, config) : citySpec(seed, MAP, config);
  const st = createState(spec, config, seed);
  const b = createBot(bot, null, BUILD);
  const cmds: Command[] = [];
  const r: Run = {
    bot, seed, firstAmber: null, firstRed: null, firstAmberAfter1: null, firstRedAfter1: null, firstAmberKitted: null, firstRedKitted: null, firstLoss: null, firstEnclosure: null,
    lost: 0, stalls: 0, firstStall: null, claims: 0, held: {}, front180: 0, interior180: 0, copper180: 0, steel180: 0,
    minSteel: Infinity, minSteelAt: 0, patchOutAt: null, assemblers: [], production180: 0, peakDemand: 0, peakDemandAt: 0,
    mags: 0, magsMade: 0, magsPerHeld: 0, amberTicks: 0, redTicks: 0,
    slots: {}, maxAsmBefore120: 0, machinesLost: 0, distinctLost: 0, dryLog: [],
  };
  const ticks = Math.round(HOURS * 3600);
  const cap = config.hopper;
  let lastReact = -Infinity;
  for (let k = 0; k < ticks; k++) {
    cmds.length = 0;
    botCommands(st, b, cmds);
    if (REACT && config.economy && st.t > 0 && st.t % 60 === 0 && st.t - lastReact >= 600) {
      let w = 1;
      for (const e of st.ring) { const l = e.hopper / cap; if (l < w) w = l; }
      const ac = config.eco.assemblerCost;
      if (pipOf(w) !== 'green' && st.stock.copper >= ac.copper && st.stock.steel >= ac.steel) { cmds.push({ type: 'addAssembler' }); lastReact = st.t; }
    }
    step(st, cmds);
    for (const ev of takeEvents(st)) {
      if (ev.type === 'claim-rejected' && ev.reason.startsWith('cannot afford')) { r.stalls++; if (r.firstStall === null) r.firstStall = ev.t; }
      if (ev.type === 'assembler') r.assemblers.push(ev.t);
    }
    // pips
    let worst = 1;
    for (const e of st.ring) { if (e.born === st.t) continue; const l = e.hopper / cap; if (l < worst) worst = l; }   // never a pip on its birth tick
    const p = pipOf(worst);
    if (p !== 'green') { r.amberTicks++; if (r.firstAmber === null) r.firstAmber = st.t; if (st.t >= 60 && r.firstAmberAfter1 === null) r.firstAmberAfter1 = st.t; }
    if (p === 'red') { r.redTicks++; if (r.firstRed === null) r.firstRed = st.t; if (st.t >= 60 && r.firstRedAfter1 === null) r.firstRedAfter1 = st.t; }
    // D-R2: the same ladder over kitted edges only (an unkitted edge is red by construction until the kit walks out)
    let worstKitted = 1;
    for (const e of st.ring) { if (e.kit === false || e.born === st.t) continue; const l = e.hopper / cap; if (l < worstKitted) worstKitted = l; }
    const pk = pipOf(worstKitted);
    if (st.t >= 60 && pk !== 'green' && r.firstAmberKitted === null) r.firstAmberKitted = st.t;
    if (st.t >= 60 && pk === 'red' && r.firstRedKitted === null) r.firstRedKitted = st.t;
    if (st.stock.steel < r.minSteel) { r.minSteel = st.stock.steel; r.minSteelAt = st.t; }
    if (r.patchOutAt === null && st.patch.steel <= 0 && config.economy) r.patchOutAt = st.t;
    if (st.t % 60 === 0) {
      const am = ammoStatus(st);
      if (am.demandMagPerMin > r.peakDemand) { r.peakDemand = am.demandMagPerMin; r.peakDemandAt = st.t; }
      if (st.t % 1800 === 0) r.held[st.t / 60] = heldCount(st);
      if (st.t % 3600 === 0) { const si = slotInfo(st); r.slots[st.t / 60] = { used: si.used, free: si.free, dry: si.dry }; }
      if (st.t < 7200) r.maxAsmBefore120 = Math.max(r.maxAsmBefore120, asmCount(st, st.t));
    }
  }
  r.firstLoss = st.stats.firstFall >= 0 ? st.stats.firstFall : null;
  r.firstEnclosure = st.stats.firstInterior >= 0 ? st.stats.firstInterior : null;
  r.lost = st.stats.lost; r.claims = st.stats.claims;
  r.front180 = frontage(st); r.interior180 = interior(st);
  r.copper180 = st.stock.copper; r.steel180 = st.stock.steel;
  r.production180 = ammoStatus(st).productionMagPerMin;
  r.mags = st.totalRounds / 10; r.magsMade = st.stats.magsMade;
  const h = heldCount(st); r.magsPerHeld = h ? r.mags / h : 0;
  r.machinesLost = st.stats.machinesLost; r.dryLog = st.stats.dryLog.slice();
  r.distinctLost = new Set(st.stats.lostLog.map(l => l.x * 1000 + l.y)).size;
  return r;
}

const m = (t: number | null) => t === null ? 'never' : (t / 60).toFixed(0) + 'm';
const runs: Run[] = [];
for (const bot of BOTS) for (const seed of SEEDS) runs.push(run(bot, seed));

console.log(`config ${HASH}  map=${MAP} walk=${WALK ? 1 : 0} economy=${ECONOMY ? 1 : 0} build=${BUILD ? 1 : 0} react=${REACT ? 1 : 0} hours=${HOURS}  overrides ${overridesArg}`);
console.log('bot      seed amber  amber1  red    red1   amberK redK   loss   encl   lost stalls(first) held60/120/180  front Cu180 steel180 minSteel(at) patchOut asm(built at)          prod180 peakDem(at)   mags  mags/held pressure% slots used/free@60,120,180  dry@60/120/180 mLost');
for (const r of runs) {
  const asm = r.assemblers.length ? r.assemblers.map(t => m(t)).join(',') : '-';
  console.log(
    `${r.bot.padEnd(8)} ${String(r.seed).padEnd(4)} ${m(r.firstAmber).padEnd(6)} ${m(r.firstAmberAfter1).padEnd(7)} ${m(r.firstRed).padEnd(6)} ${m(r.firstRedAfter1).padEnd(6)} ${m(r.firstAmberKitted).padEnd(6)} ${m(r.firstRedKitted).padEnd(6)} ${m(r.firstLoss).padEnd(6)} ${m(r.firstEnclosure).padEnd(6)} ` +
    `${String(r.lost).padEnd(4)} ${(r.stalls + (r.firstStall !== null ? '(' + m(r.firstStall) + ')' : '')).padEnd(13)} ` +
    `${String(r.held[60] ?? 0)}/${String(r.held[120] ?? 0)}/${String(r.held[180] ?? 0)}`.padEnd(15) +
    ` ${String(r.front180).padEnd(5)} ${r.copper180.toFixed(0).padEnd(5)} ${r.steel180.toFixed(0).padEnd(8)} ${(r.minSteel.toFixed(0) + '(' + m(r.minSteelAt) + ')').padEnd(12)} ${m(r.patchOutAt).padEnd(8)} ` +
    `${asm.padEnd(22)} ${r.production180.toFixed(0).padEnd(7)} ${(r.peakDemand.toFixed(1) + '(' + m(r.peakDemandAt) + ')').padEnd(13)} ${r.mags.toFixed(0).padEnd(5)} ${r.magsPerHeld.toFixed(0).padEnd(9)} ${(100 * r.amberTicks / (HOURS * 3600)).toFixed(1).padEnd(9)} ` +
    `${[60, 120, 180].map(k => r.slots[k] ? `${r.slots[k].used}/${r.slots[k].free}` : '-').join(' ').padEnd(27)} ${[60, 120, 180].map(k => r.slots[k] ? r.slots[k].dry : '-').join('/').padEnd(14)} ${r.machinesLost}`);
}

// ---- targets
const by = (bot: Policy) => runs.filter(r => r.bot === bot);
const min = (t: number | null) => t === null ? Infinity : t / 60;
const all = (rs: Run[], f: (r: Run) => boolean) => rs.length > 0 && rs.every(f);
const fmt = (rs: Run[], f: (r: Run) => string) => rs.map(r => `s${r.seed}:${f(r)}`).join(' ');
const compact = by('compact'), spike = by('spike'), cheapest = by('cheapest');
const compactOf = (seed: number) => compact.find(r => r.seed === seed);
// The constitution's seven Phase 2 targets (C1–C7), every seed; then two informational rows the earlier reports tracked.
const targets: [string, string, boolean, string][] = [
  ['C1', 'compact: first enclosure before first amber on a kitted edge (from minute 1, D-R2)', all(compact, r => min(r.firstEnclosure) < min(r.firstAmberKitted)), fmt(compact, r => `encl ${m(r.firstEnclosure)} amber ${m(r.firstAmberKitted)}`)],
  ['C2', 'compact: no red on a kitted edge before 120 min (from minute 1, D-R2)', all(compact, r => min(r.firstRedKitted) >= 120), fmt(compact, r => m(r.firstRedKitted))],
  ['C3', 'compact: 0 lost and no stall to 180', all(compact, r => r.lost === 0 && r.stalls === 0), fmt(compact, r => `lost ${r.lost} stalls ${r.stalls}`)],
  ['C4', 'spike: red by 90 min', all(spike, r => min(r.firstRed) <= 90), fmt(spike, r => m(r.firstRed))],
  ['C5', 'spike: 1–4 distinct blocks lost by 180', all(spike, r => r.distinctLost >= 1 && r.distinctLost <= 4), fmt(spike, r => `${r.distinctLost} distinct (${r.lost} falls)`)],
  ['C6', 'spike: never more than 2 assemblers before 120 min', all(spike, r => r.maxAsmBefore120 <= 2), fmt(spike, r => `max ${r.maxAsmBefore120}`)],
  ['C7', 'cheapest: no stall; ammo per held block 0.7–1.3× compact', all(cheapest, r => { const c = compactOf(r.seed); return r.stalls === 0 && !!c && c.magsPerHeld > 0 && r.magsPerHeld / c.magsPerHeld >= 0.7 && r.magsPerHeld / c.magsPerHeld <= 1.3; }),
    fmt(cheapest, r => { const c = compactOf(r.seed); return `stalls ${r.stalls} ratio ${c && c.magsPerHeld ? (r.magsPerHeld / c.magsPerHeld).toFixed(2) : '?'}`; })],
  ['i1', 'info — compact: first amber on a kitted edge 60–120 min (CALIBRATION_REPORT T1)', all(compact, r => min(r.firstAmberKitted) >= 60 && min(r.firstAmberKitted) <= 120), fmt(compact, r => m(r.firstAmberKitted))],
  ['i2', 'info — all: held at 120 min in 20–30 (CALIBRATION_REPORT T7)', all(runs, r => (r.held[120] ?? 0) >= 20 && (r.held[120] ?? 0) <= 30), runs.map(r => `${r.bot[0]}${r.seed}:${r.held[120] ?? 0}`).join(' ')],
];
console.log('');
for (const [id, what, ok, val] of targets) console.log(`${id} ${ok ? 'MET   ' : 'MISSED'} ${what.padEnd(58)} ${val}`);
const payload = { ...PROV, hash: HASH, map: MAP, walk: WALK, overrides: JSON.parse(overridesArg), economy: ECONOMY, build: BUILD, react: REACT, hours: HOURS, config, runs, targets: targets.map(([id, what, ok, val]) => ({ id, what, ok, val })) };
if (OUT) writeFileSync(OUT, JSON.stringify(payload, null, 1));
const MD = flag('--md', '') && resolve(CWD, flag('--md', ''));
if (MD) {
  const lines: string[] = [];
  lines.push(stampLine(PROV));
  lines.push(`<!-- generated by packages/harness/src/calibrate.ts; config ${HASH}; map=${MAP} walk=${WALK ? 1 : 0} economy=${ECONOMY ? 1 : 0} build=${BUILD ? 1 : 0} react=${REACT ? 1 : 0} hours=${HOURS}; overrides ${overridesArg} -->`, '');
  lines.push('| bot | seed | enclosure | amber | amber after 1 min | red | red after 1 min | amber kitted | red kitted | first loss | lost (distinct) | stalls | held 60/120/180 | front 180 | assemblers built at | max asm < 120 | mags | mags/held | steel min (at) | patch out | dry 180 |', '|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|');
  for (const r of runs) lines.push(`| ${r.bot} | ${r.seed} | ${m(r.firstEnclosure)} | ${m(r.firstAmber)} | ${m(r.firstAmberAfter1)} | ${m(r.firstRed)} | ${m(r.firstRedAfter1)} | ${m(r.firstAmberKitted)} | ${m(r.firstRedKitted)} | ${m(r.firstLoss)} | ${r.lost} (${r.distinctLost}) | ${r.stalls} | ${r.held[60] ?? 0}/${r.held[120] ?? 0}/${r.held[180] ?? 0} | ${r.front180} | ${r.assemblers.length ? r.assemblers.map(t => m(t)).join(', ') : '–'} | ${r.maxAsmBefore120} | ${r.mags.toFixed(0)} | ${r.magsPerHeld.toFixed(0)} | ${r.minSteel.toFixed(0)} (${m(r.minSteelAt)}) | ${m(r.patchOutAt)} | ${r.slots[180]?.dry ?? '–'} |`);
  lines.push('', '| target | result | per seed |', '|---|---|---|');
  for (const [id, what, ok, val] of targets) lines.push(`| ${id} ${what} | ${ok ? 'MET' : 'MISSED'} | ${val} |`);
  writeFileSync(MD, lines.join('\n') + '\n');
}
