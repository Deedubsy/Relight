/** P7-01: saved campaign recruits. Existing restoration/cache records keep owning their rewards. */
import { type SimState, HELD, DARK } from './types';
import { idxOf } from './sim';
import { ground, inReach } from './ground';
import { passable } from './walk';
import { isCampaign } from './rules';

export const RECRUITS = { electricians: { name: 'Electricians', reward: 'Floodlight and Big pole', clueRadius: 24 } } as const;
export type RecruitKind = keyof typeof RECRUITS;
export interface RecruitSite {
  id: string; kind: RecruitKind; block: number; x: number; y: number;
  seenAt: number; recruitedAt: number; inherited: boolean;
}
export interface RecruitState { version: 1; sites: RecruitSite[] }
export const recruitId = (seed: number, kind: RecruitKind): string => `${seed}:recruit:${kind}:v1`;

/** Old earned unlocks are imported once, including a formerly Held/fallen Electricians block. */
export function initRecruits(st: SimState): void {
  const c = st.campaign;
  if (!isCampaign(st) || !c || !st.flow || c.recruits) return;
  const G = ground(st), original = st.survivors.find(s => s.name === 'Electricians');
  const bi = original ? idxOf(st, original.x, original.y) : -1;
  const inherited = bi >= 0 && (st.blocks[bi].state === HELD || !!st.fallen[bi]);
  // Static geometry defines the location even when loading an older, heavily built save.
  // An existing machine is never moved or destroyed; local reach allows interaction beside it.
  const bare = { ...st, campaign: { ...c, truck: undefined }, flow: { ...st.flow, occ: {}, machines: [] } } as SimState;
  const gate = G.opening!.gate, start = gate[Math.floor(gate.length / 2)];
  const cache = c.discovery!, d = c.districts!, e = c.expansion!;
  const installations = [d.workshop, d.station, e.station, e.radio, ...d.sources];
  const route = new Set([...d.route, ...e.route]);
  const safe = (t: number): boolean => {
    const x = t % G.tw, y = Math.floor(t / G.tw);
    return passable(bare, x, y) && Math.hypot(x-cache.x,y-cache.y)>12
      && (c.defence?.sites ?? []).every(s => Math.hypot(x-s.tile%G.tw,y-Math.floor(s.tile/G.tw))>12);
  };
  const queue = [start], seen = new Set(queue);
  let chosen = -1;
  for (let head = 0; head < queue.length; head++) {
    const t = queue[head], x = t % G.tw, y = Math.floor(t / G.tw), block = G.owner[t];
    if (block >= 0 && block !== c.homeBlock && [HELD,DARK].includes(st.blocks[block].state)
      && !route.has(t) && !G.patch[t] && G.rank[t]<0 && safe(t)
      && installations.every(s => Math.hypot(x-s.x,y-s.y)>s.size+4)
      && [...e.stops,d.stop].every(([sx,sy])=>Math.hypot(x-sx,y-sy)>5)) { chosen = t; break; }
    for (const [xx,yy] of [[x,y-1],[x+1,y],[x,y+1],[x-1,y]]) {
      const q = yy*G.tw+xx;
      if(xx<0||yy<0||xx>=G.tw||yy>=G.th||seen.has(q)||!safe(q))continue;
      seen.add(q);queue.push(q);
    }
  }
  if (chosen < 0) throw new Error('campaign requires an accessible Electricians shelter');
  c.recruits = { version: 1, sites: [{ id: recruitId(st.seed,'electricians'), kind:'electricians',
    block:G.owner[chosen], x:chosen%G.tw, y:Math.floor(chosen/G.tw),
    seenAt:inherited?st.t:-1, recruitedAt:inherited?st.t:-1, inherited }] };
  c.version = 6;
}
export function recruitAt(st: SimState, x: number, y: number): RecruitSite | undefined {
  return st.campaign?.recruits?.sites.find(s => s.x===x && s.y===y);
}
export function campaignRecruited(st: SimState, kind: RecruitKind): boolean {
  return !!st.campaign?.recruits?.sites.some(s => s.kind===kind && s.recruitedAt>=0);
}
export function tickRecruits(st: SimState): void {
  for (const s of st.campaign?.recruits?.sites ?? [])
    if(s.seenAt<0 && Math.hypot(st.engineer.x-s.x-.5,st.engineer.y-s.y-.5)<=RECRUITS[s.kind].clueRadius)s.seenAt=st.t;
}
export function recruitCheck(st: SimState, id: string): string {
  const s=st.campaign?.recruits?.sites.find(s=>s.id===id);
  if(!s)return 'Unknown survivor shelter.';
  if(s.recruitedAt>=0)return `${RECRUITS[s.kind].name} already recruited; their plans are yours permanently.`;
  if(st.engineer.down>=0 || st.engineer.truckSeat || !inReach(st,s.x,s.y,1))return 'Walk closer to the shelter to recruit the Electricians.';
  return '';
}
export function recruitSurvivors(st: SimState, id: string): string {
  const why=recruitCheck(st,id);if(why)return why;
  const s=st.campaign!.recruits!.sites.find(s=>s.id===id)!;
  s.seenAt=st.t;s.recruitedAt=st.t;
  st.campaign!.defence!.notice='Electricians recruited: Floodlight and Big pole plans available. Build with carried materials and connect real power.';
  return '';
}
export function recruitDescription(_st: SimState, s: RecruitSite): string {
  return s.recruitedAt>=0 ? 'Electricians recruited · Floodlight and Big pole plans retained. Build with carried materials; lights need connected power.'
    : 'Electricians shelter · E to recruit in person. Unlocks Floodlight and Big pole plans; no block claim or restoration kit required.';
}
export function recruitsProblem(st: SimState): string {
  const c=st.campaign,r=c?.recruits;
  if((c?.version??0)<6)return r?'recruits require campaign metadata version 6':'';
  if(!r || r.version!==1 || !Array.isArray(r.sites) || r.sites.length!==1)return 'invalid campaign recruits';
  for(const s of r.sites) {
    if(!s || s.kind!=='electricians' || s.id!==recruitId(st.seed,s.kind) || !Number.isInteger(s.block) || !st.blocks[s.block]
      || !Number.isInteger(s.x) || !Number.isInteger(s.y) || s.x<0 || s.y<0 || s.x>=st.flow!.tw || s.y>=st.city!.th
      || ground(st).owner[s.y*st.flow!.tw+s.x]!==s.block || typeof s.inherited!=='boolean'
      || ![s.seenAt,s.recruitedAt].every(t=>Number.isFinite(t)&&(t===-1||(t>=0&&t<=st.t)))
      || (s.recruitedAt>=0&&(s.seenAt<0||s.seenAt>s.recruitedAt)) || (s.inherited&&s.recruitedAt<0))return 'invalid campaign recruit record';
  }
  return '';
}
