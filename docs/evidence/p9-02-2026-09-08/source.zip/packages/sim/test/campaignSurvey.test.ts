import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createCampaign,loadState,makeSave,stateHash,validateCampaignCity,initExpansion,EXPANSION_SURVEY_VERSION} from '../src/index';
import {loadSnapshot} from '../../game/src/session';

for(const seed of [6,29])test(`survey revision 2: seed ${seed} composes legal tracks/stops and preserves an older paid save`,()=>{
 const fresh=createCampaign(seed),report=validateCampaignCity(fresh);
 assert.equal(fresh.campaign!.expansion!.surveyVersion,EXPANSION_SURVEY_VERSION);assert.ok(report.ok,JSON.stringify(report.failures));
 assert.deepEqual(validateCampaignCity(loadState(makeSave(fresh))),report);
 const old=JSON.parse(readFileSync(new URL(`../../../docs/evidence/p9-02-2026-09-08/old-seed-${seed}.json`,import.meta.url),'utf8'));
 const loaded=loadState(old),hash=stateHash(loaded);assert.equal(hash,old.hash);
 assert.deepEqual(loaded.campaign!.expansion,old.state.campaign.expansion);assert.deepEqual(loaded.campaign!.districts,old.state.campaign.districts);
 assert.deepEqual(loaded.engineer.inv,old.state.engineer.inv);assert.deepEqual(loaded.flow!.machines,old.state.flow.machines);
 initExpansion(loaded);assert.equal(stateHash(loaded),hash,'existing surveys must never regenerate');
 assert.notDeepEqual(fresh.campaign!.expansion!.route,loaded.campaign!.expansion!.route);
});

test('old survey logs remain available but cannot claim new-factory replay; new survey saves retain complete logs',async()=>{
 const old=readFileSync(new URL('../../../docs/evidence/p9-02-2026-09-08/old-seed-6.json',import.meta.url),'utf8'),raw=JSON.parse(old);
 const descriptor=Object.getOwnPropertyDescriptor(globalThis,'localStorage');let contents=old;
 Object.defineProperty(globalThis,'localStorage',{configurable:true,value:{getItem:()=>contents}});
 try {
  const loaded=await loadSnapshot('local:survey');assert.equal(loaded.logComplete,false);assert.deepEqual(loaded.log,raw.log);assert.equal(stateHash(loaded.state),raw.hash);
  contents=JSON.stringify(makeSave(createCampaign(6),{log:[],logComplete:true}));const current=await loadSnapshot('local:survey');assert.equal(current.logComplete,true);assert.equal(current.state.campaign!.expansion!.surveyVersion,2);
 }finally{if(descriptor)Object.defineProperty(globalThis,'localStorage',descriptor);else Reflect.deleteProperty(globalThis,'localStorage');}
});

test('unknown survey revision refuses load without treating the saved route as a new survey',()=>{
 const raw=JSON.parse(JSON.stringify(makeSave(createCampaign(6))));raw.state.campaign.expansion.surveyVersion=3;
 assert.throws(()=>loadState(raw),/survey revision/);
});
