import {writeFileSync} from 'node:fs';
import {createCampaign,makeSave,stateHash} from '../../../packages/sim/src/index';
const records=[];
for(const seed of [102,305,842]){const st=createCampaign(seed);writeFileSync(new URL(`fresh-${seed}.json`,import.meta.url),JSON.stringify(makeSave(st,{log:[],logComplete:true})),{flag:'wx'});records.push({seed,hash:stateHash(st),survey:st.campaign!.expansion!.surveyVersion});}
writeFileSync(new URL('prepared.json',import.meta.url),JSON.stringify(records,null,2)+'\n',{flag:'wx'});
