/** Reject corrupt/partial campaign threat saves instead of silently resetting their schedule. */
import type { SimState } from './types';
import { DEFENCE } from './campaignDefence';
export function defenceProblem(st:SimState):string {
  const d=st.campaign?.defence;
  if((st.campaign?.version??0)<3)return d?'defence requires campaign metadata version 3':'';
  if(!d||d.version!==1||!st.flow||!Array.isArray(d.bases)||!Array.isArray(d.nominations)||!Array.isArray(d.sites)||!Array.isArray(d.history))return 'invalid campaign defence state';
  const number=(n:unknown)=>typeof n==='number'&&Number.isFinite(n);
  const integer=(n:unknown,min=0)=>number(n)&&Number.isInteger(n)&&(n as number)>=min;
  const tile=(n:unknown)=>integer(n)&&(n as number)<st.flow!.tw*st.city!.th;
  const block=(n:unknown)=>integer(n)&&!!st.blocks[n as number];
  if(!integer(d.nextId,1)||!integer(d.nextDawn)||!integer(d.lastMajorEnd,-1)||!integer(d.lastMinorSlot,-1)||!integer(d.raidsStarted)||!integer(d.majorSpawned)||typeof d.radioUpgrade!=='boolean'||typeof d.notice!=='string')return 'invalid campaign schedule';
  if(new Set(d.bases.map(b=>b.block)).size!==d.bases.length||!d.bases.some(b=>b.block===st.campaign!.homeBlock))return 'invalid campaign base registry';
  for(const b of d.bases)if(!block(b.block)||!integer(b.x)||!integer(b.y)||!integer(b.size,1)||b.x+b.size>st.flow.tw||b.y+b.size>st.city!.th||!number(b.hp)||b.hp<0||b.hp>DEFENCE.coreHp||!integer(b.commissionedAt))return 'invalid campaign base';
  const station=st.campaign!.expansion?.station;
  const stations=[station,st.campaign!.districts?.station].filter(s=>s!==undefined);
  if(d.bases.some(b=>b.block!==st.campaign!.homeBlock&&!stations.some(s=>s!.block===b.block))||stations.some(s=>!!d.bases.find(b=>b.block===s!.block)!==(s!.restoredAt>=0)))return 'campaign bases disagree with restoration';
  if(d.nominations.some(n=>!d.bases.some(b=>b.block===n.block)||!integer(n.at))||new Set(d.nominations.map(n=>n.block)).size!==d.nominations.length)return 'invalid restoration nominations';
  for(const a of [d.major,d.minor])if(a!==null&&(!a||!integer(a.id,1)||a.id>=d.nextId||!d.bases.some(b=>b.block===a.block)||!tile(a.origin)||typeof a.retreat!=='boolean'))return 'invalid campaign attack';
  if(d.major&&(!integer(d.major.dawn)||!integer(d.major.startsAt)||d.major.startsAt<d.major.dawn||!integer(d.major.remaining)||d.major.remaining>60||!integer(d.major.nextSpawn)))return 'invalid major roster';
  if(d.warning&&(!integer(d.warning.assault,1)||!block(d.warning.block)||!integer(d.warning.startsAt)||!integer(d.warning.receivedAt)||(d.major&&d.warning.assault===d.major.id&&(d.warning.block!==d.major.block||d.warning.startsAt!==d.major.startsAt))))return 'invalid radio warning';
  if(d.sites.some(s=>!integer(s.id,1)||!block(s.block)||!tile(s.tile)||typeof s.spawned!=='boolean')||new Set(d.sites.map(s=>s.id)).size!==d.sites.length)return 'invalid ruin guards';
  if(d.history.some(h=>!integer(h.id,1)||!block(h.block)||!integer(h.started)||!integer(h.ended)||h.ended<h.started||typeof h.defeated!=='boolean'||!integer(h.spawned)))return 'invalid assault history';
  const r=d.repair;
  if(r&&(typeof r.recommission!=='boolean'||!number(r.remaining)||r.remaining<0||(r.kind==='core'?!d.bases.some(b=>b.block===r.id):r.kind==='machine'?!st.flow.machines.some(m=>m.id===r.id&&(m.kind==='wall'||m.kind==='turret')):true)))return 'invalid paid repair';
  for(const m of st.flow.machines)if(m.hp!==undefined&&(!number(m.hp)||m.hp<0||(m.kind!=='wall'&&m.kind!=='turret')||m.hp>(m.kind==='wall'?DEFENCE.wallHp:DEFENCE.turretHp)))return 'invalid defence health';
  for(const c of st.flow.threat?.crawlers??[]) {
    const m=c.campaign;
    if(!m||!['site','minor','major'].includes(m.layer)||!integer(m.group,1)||!tile(m.origin)||(m.waypoint!==undefined&&!tile(m.waypoint))||!number(c.x)||!number(c.y)||c.x<0||c.y<0||c.x>=st.flow.tw||c.y>=st.city!.th||!number(c.hp)||c.hp<=0)return 'invalid campaign creature';
    if(m.layer==='site'?!d.sites.some(s=>s.id===m.group):m.layer==='minor'?d.minor?.id!==m.group:d.major?.id!==m.group)return 'orphaned campaign creature';
  }
  return '';
}
